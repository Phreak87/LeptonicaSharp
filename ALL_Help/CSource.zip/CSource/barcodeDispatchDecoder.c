﻿
char *
barcodeDispatchDecoder(char    *barstr,
                       l_int32  format,
                       l_int32  debugflag)
{
char  *data = NULL;

    PROCNAME("barcodeDispatchDecoder");

    if (!barstr)
        return (char *)ERROR_PTR("barstr not defined", procName, NULL);

    debugflag = FALSE;  /* not used yet */

    if (format == L_BF_ANY)
        format = barcodeFindFormat(barstr);

    if (format == L_BF_CODE2OF5)
        data = barcodeDecode2of5(barstr, debugflag);
    else if (format == L_BF_CODEI2OF5)
        data = barcodeDecodeI2of5(barstr, debugflag);
    else if (format == L_BF_CODE93)
        data = barcodeDecode93(barstr, debugflag);
    else if (format == L_BF_CODE39)
    	data = barcodeDecode39(barstr, debugflag);
    else if (format == L_BF_CODABAR)
    	data = barcodeDecodeCodabar(barstr, debugflag);
    else if (format == L_BF_UPCA)
    	data = barcodeDecodeUpca(barstr, debugflag);
    else if (format == L_BF_EAN13)
    	data = barcodeDecodeEan13(barstr, 0, debugflag);
    else
        return (char *)ERROR_PTR("format not implemented", procName, NULL);

    return data;
}