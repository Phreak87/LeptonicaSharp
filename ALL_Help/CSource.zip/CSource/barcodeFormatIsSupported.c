﻿
l_int32
barcodeFormatIsSupported(l_int32  format)
{
l_int32  i;

   for (i = 0; i < NumSupportedBarcodeFormats; i++) {
       if (format == SupportedBarcodeFormat[i])
           return 1;
   }
   return 0;
}