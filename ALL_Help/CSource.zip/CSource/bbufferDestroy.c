﻿
void
bbufferDestroy(L_BBUFFER  **pbb)
{
L_BBUFFER  *bb;

    PROCNAME("bbufferDestroy");

    if (pbb == NULL) {
        L_WARNING("ptr address is NULL\n", procName);
        return;
    }

    if ((bb = *pbb) == NULL)
        return;

    if (bb->array)
        LEPT_FREE(bb->array);
    LEPT_FREE(bb);
    *pbb = NULL;

    return;
}