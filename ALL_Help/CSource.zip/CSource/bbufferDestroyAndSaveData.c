﻿
l_uint8 *
bbufferDestroyAndSaveData(L_BBUFFER  **pbb,
                          size_t      *pnbytes)
{
l_uint8    *array;
size_t      nbytes;
L_BBUFFER  *bb;

    PROCNAME("bbufferDestroyAndSaveData");

    if (pbb == NULL) {
        L_WARNING("ptr address is NULL\n", procName);
        return NULL;
    }
    if (pnbytes == NULL) {
        L_WARNING("&nbytes is NULL\n", procName);
        bbufferDestroy(pbb);
        return NULL;
    }

    if ((bb = *pbb) == NULL)
        return NULL;

        /* write all unwritten bytes out to a new array */
    nbytes = bb->n - bb->nwritten;
    *pnbytes = nbytes;
    if ((array = (l_uint8 *)LEPT_CALLOC(nbytes, sizeof(l_uint8))) == NULL) {
        L_WARNING("calloc failure for array\n", procName);
        return NULL;
    }
    memcpy(array, bb->array + bb->nwritten, nbytes);

    bbufferDestroy(pbb);
    return array;
}