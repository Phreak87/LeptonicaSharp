﻿
l_ok
bbufferRead(L_BBUFFER  *bb,
            l_uint8    *src,
            l_int32     nbytes)
{
l_int32  navail, nadd, nwritten;

    PROCNAME("bbufferRead");

    if (!bb)
        return ERROR_INT("bb not defined", procName, 1);
    if (!src)
        return ERROR_INT("src not defined", procName, 1);
    if (nbytes == 0)
        return ERROR_INT("no bytes to read", procName, 1);

    if ((nwritten = bb->nwritten)) {  /* move the unwritten bytes over */
        memmove(bb->array, bb->array + nwritten, bb->n - nwritten);
        bb->nwritten = 0;
        bb->n -= nwritten;
    }

        /* If necessary, expand the allocated array.  Do so by
         * by at least a factor of two. */
    navail = bb->nalloc - bb->n;
    if (nbytes > navail) {
        nadd = L_MAX(bb->nalloc, nbytes);
        bbufferExtendArray(bb, nadd);
    }

        /* Read in the new bytes */
    memcpy(bb->array + bb->n, src, nbytes);
    bb->n += nbytes;

    return 0;
}