﻿
l_ok
bbufferReadStream(L_BBUFFER  *bb,
                  FILE       *fp,
                  l_int32     nbytes)
{
l_int32  navail, nadd, nread, nwritten;

    PROCNAME("bbufferReadStream");

    if (!bb)
        return ERROR_INT("bb not defined", procName, 1);
    if (!fp)
        return ERROR_INT("fp not defined", procName, 1);
    if (nbytes == 0)
        return ERROR_INT("no bytes to read", procName, 1);

    if ((nwritten = bb->nwritten)) {  /* move any unwritten bytes over */
        memmove(bb->array, bb->array + nwritten, bb->n - nwritten);
        bb->nwritten = 0;
        bb->n -= nwritten;
    }

        /* If necessary, expand the allocated array.  Do so by
         * by at least a factor of two. */
    navail = bb->nalloc - bb->n;
    if (nbytes > navail) {
        nadd = L_MAX(bb->nalloc, nbytes);
        bbufferExtendArray(bb, nadd);
    }

        /* Read in the new bytes */
    nread = fread(bb->array + bb->n, 1, nbytes, fp);
    bb->n += nread;

    return 0;
}