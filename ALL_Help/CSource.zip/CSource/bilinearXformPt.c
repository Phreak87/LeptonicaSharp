﻿
l_ok
bilinearXformPt(l_float32  *vc,
                l_int32     x,
                l_int32     y,
                l_float32  *pxp,
                l_float32  *pyp)
{
    PROCNAME("bilinearXformPt");

    if (!vc)
        return ERROR_INT("vc not defined", procName, 1);

    *pxp = vc[0] * x + vc[1] * y + vc[2] * x * y + vc[3];
    *pyp = vc[4] * x + vc[5] * y + vc[6] * x * y + vc[7];
    return 0;
}