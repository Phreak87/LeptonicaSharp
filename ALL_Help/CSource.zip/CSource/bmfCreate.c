﻿
L_BMF *
bmfCreate(const char  *dir,
          l_int32      fontsize)
{
L_BMF   *bmf;
PIXA  *pixa;

    PROCNAME("bmfCreate");

    if (fontsize < 4 || fontsize > 20 || (fontsize % 2))
        return (L_BMF *)ERROR_PTR("fontsize must be in {4, 6, ..., 20}",
                                  procName, NULL);
    if ((bmf = (L_BMF *)LEPT_CALLOC(1, sizeof(L_BMF))) == NULL)
        return (L_BMF *)ERROR_PTR("bmf not made", procName, NULL);

    if (!dir) {  /* Generate from a string */
        pixa = pixaGenerateFontFromString(fontsize, &bmf->baseline1,
                                          &bmf->baseline2, &bmf->baseline3);
    } else {  /* Look for the pixa in a directory */
        pixa = pixaGetFont(dir, fontsize, &bmf->baseline1, &bmf->baseline2,
                           &bmf->baseline3);
        if (!pixa) {  /* Not found; make it from a file */
            L_INFO("Generating pixa of bitmap fonts from file\n", procName);
            pixa = pixaGenerateFontFromFile(dir, fontsize, &bmf->baseline1,
                                            &bmf->baseline2, &bmf->baseline3);
            if (!pixa) {  /* Not made; make it from a string after all */
                L_ERROR("Failed to make font; use string\n", procName);
                pixa = pixaGenerateFontFromString(fontsize, &bmf->baseline1,
                                          &bmf->baseline2, &bmf->baseline3);
            }
        }
    }

    if (!pixa) {
        bmfDestroy(&bmf);
        return (L_BMF *)ERROR_PTR("font pixa not made", procName, NULL);
    }

    bmf->pixa = pixa;
    bmf->size = fontsize;
    if (dir) bmf->directory = stringNew(dir);
    bmfMakeAsciiTables(bmf);
    return bmf;
}