﻿
void
bmfDestroy(L_BMF  **pbmf)
{
L_BMF  *bmf;

    PROCNAME("bmfDestroy");

    if (pbmf == NULL) {
        L_WARNING("ptr address is null!\n", procName);
        return;
    }

    if ((bmf = *pbmf) == NULL)
        return;

    pixaDestroy(&bmf->pixa);
    LEPT_FREE(bmf->directory);
    LEPT_FREE(bmf->fonttab);
    LEPT_FREE(bmf->baselinetab);
    LEPT_FREE(bmf->widthtab);
    LEPT_FREE(bmf);
    *pbmf = NULL;
    return;
}