﻿
l_ok
bmfGetBaseline(L_BMF    *bmf,
               char      chr,
               l_int32  *pbaseline)
{
l_int32  bl, index;

    PROCNAME("bmfGetBaseline");

    if (!pbaseline)
        return ERROR_INT("&baseline not defined", procName, 1);
    *pbaseline = 0;
    if (!bmf)
        return ERROR_INT("bmf not defined", procName, 1);
    if ((index = (l_int32)chr) == 10)  /* NL */
        return 0;

    bl = bmf->baselinetab[index];
    if (bl == UNDEF) {
        L_ERROR("no bitmap representation for %d\n", procName, index);
        return 1;
    }

    *pbaseline = bl;
    return 0;
}