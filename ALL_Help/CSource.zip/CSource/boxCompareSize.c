﻿
l_ok
boxCompareSize(BOX      *box1,
               BOX      *box2,
               l_int32   type,
               l_int32  *prel)
{
l_int32  w1, h1, w2, h2, size1, size2;

    PROCNAME("boxCompareSize");

    if (!prel)
        return ERROR_INT("&rel not defined", procName, 1);
    *prel = 0;
    if (!box1 || !box2)
        return ERROR_INT("box1 and box2 not both defined", procName, 1);
    if (type != L_SORT_BY_WIDTH && type != L_SORT_BY_HEIGHT &&
        type != L_SORT_BY_MAX_DIMENSION && type != L_SORT_BY_PERIMETER &&
        type != L_SORT_BY_AREA)
        return ERROR_INT("invalid compare type", procName, 1);

    boxGetGeometry(box1, NULL, NULL, &w1, &h1);
    boxGetGeometry(box2, NULL, NULL, &w2, &h2);
    if (type == L_SORT_BY_WIDTH) {
        *prel = (w1 > w2) ? 1 : ((w1 == w2) ? 0 : -1);
    } else if (type == L_SORT_BY_HEIGHT) {
        *prel = (h1 > h2) ? 1 : ((h1 == h2) ? 0 : -1);
    } else if (type == L_SORT_BY_MAX_DIMENSION) {
        size1 = L_MAX(w1, h1);
        size2 = L_MAX(w2, h2);
        *prel = (size1 > size2) ? 1 : ((size1 == size2) ? 0 : -1);
    } else if (type == L_SORT_BY_PERIMETER) {
        size1 = w1 + h1;
        size2 = w2 + h2;
        *prel = (size1 > size2) ? 1 : ((size1 == size2) ? 0 : -1);
    } else if (type == L_SORT_BY_AREA) {
        size1 = w1 * h1;
        size2 = w2 * h2;
        *prel = (size1 > size2) ? 1 : ((size1 == size2) ? 0 : -1);
    }
    return 0;
}