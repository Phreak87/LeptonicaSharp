﻿
l_ok
boxPrintStreamInfo(FILE  *fp,
                   BOX   *box)
{
    PROCNAME("boxPrintStreamInfo");

    if (!fp)
        return ERROR_INT("stream not defined", procName, 1);
    if (!box)
        return ERROR_INT("box not defined", procName, 1);

    fprintf(fp, " Box: x = %d, y = %d, w = %d, h = %d\n",
            box->x, box->y, box->w, box->h);
    return 0;
}