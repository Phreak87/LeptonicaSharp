﻿
BOXA *
boxaCombineOverlaps(BOXA  *boxas,
                    PIXA  *pixadb)
{
l_int32  i, j, w, h, n1, n2, overlap, niters;
BOX     *box1, *box2, *box3;
BOXA    *boxa1, *boxa2;
PIX     *pix1;

    PROCNAME("boxaCombineOverlaps");

    if (!boxas)
        return (BOXA *)ERROR_PTR("boxas not defined", procName, NULL);

    if (pixadb) boxaGetExtent(boxas, &w, &h, NULL);

    boxa1 = boxaCopy(boxas, L_COPY);
    n1 = boxaGetCount(boxa1);
    niters = 0;
    while (1) {  /* loop until no change from previous iteration */
        niters++;
        if (pixadb) {
            pix1 = pixCreate(w + 5, h + 5, 32);
            pixSetAll(pix1);
            pixRenderBoxaArb(pix1, boxa1, 2, 255, 0, 0);
            pixaAddPix(pixadb, pix1, L_COPY);
        }

            /* Combine overlaps for this iteration */
        for (i = 0; i < n1; i++) {
            if ((box1 = boxaGetValidBox(boxa1, i, L_COPY)) == NULL)
                continue;
            for (j = i + 1; j < n1; j++) {
                if ((box2 = boxaGetValidBox(boxa1, j, L_COPY)) == NULL)
                    continue;
                boxIntersects(box1, box2, &overlap);
                if (overlap) {
                    box3 = boxBoundingRegion(box1, box2);
                    boxaReplaceBox(boxa1, i, box3);
                    boxaReplaceBox(boxa1, j, boxCreate(0, 0, 0, 0));
                    boxDestroy(&box1);
                    box1 = boxCopy(box3);
                }
                boxDestroy(&box2);
            }
            boxDestroy(&box1);
        }
        boxa2 = boxaSaveValid(boxa1, L_COPY);
        n2 = boxaGetCount(boxa2);
        boxaDestroy(&boxa1);
        boxa1 = boxa2;
        if (n1 == n2) {
            if (pixadb) pixDestroy(&pix1);
            break;
        }
        n1 = n2;
        if (pixadb) {
            pixRenderBoxaArb(pix1, boxa1, 2, 0, 255, 0);
            pixaAddPix(pixadb, pix1, L_INSERT);
        }
    }

    if (pixadb)
        L_INFO("number of iterations: %d\n", procName, niters);
    return boxa1;
}