﻿
l_ok
boxaCombineOverlapsInPair(BOXA   *boxas1,
                          BOXA   *boxas2,
                          BOXA  **pboxad1,
                          BOXA  **pboxad2,
                          PIXA   *pixadb)
{
l_int32  i, j, w, h, w2, h2, n1, n2, n1i, n2i, niters;
l_int32  overlap, bigger, area1, area2;
BOX     *box1, *box2, *box3;
BOXA    *boxa1, *boxa2, *boxac1, *boxac2;
PIX     *pix1;

    PROCNAME("boxaCombineOverlapsInPair");

    if (pboxad1) *pboxad1 = NULL;
    if (pboxad2) *pboxad2 = NULL;
    if (!boxas1 || !boxas2)
        return ERROR_INT("boxas1 and boxas2 not both defined", procName, 1);
    if (!pboxad1 || !pboxad2)
        return ERROR_INT("&boxad1 and &boxad2 not both defined", procName, 1);

    if (pixadb) {
        boxaGetExtent(boxas1, &w, &h, NULL);
        boxaGetExtent(boxas2, &w2, &h2, NULL);
        w = L_MAX(w, w2);
        h = L_MAX(h, w2);
    }

        /* Let the boxa with the largest area have first crack at the other */
    boxaGetArea(boxas1, &area1);
    boxaGetArea(boxas2, &area2);
    if (area1 >= area2) {
        boxac1 = boxaCopy(boxas1, L_COPY);
        boxac2 = boxaCopy(boxas2, L_COPY);
    } else {
        boxac1 = boxaCopy(boxas2, L_COPY);
        boxac2 = boxaCopy(boxas1, L_COPY);
    }

    n1i = boxaGetCount(boxac1);
    n2i = boxaGetCount(boxac2);
    niters = 0;
    while (1) {
        niters++;
        if (pixadb) {
            pix1 = pixCreate(w + 5, h + 5, 32);
            pixSetAll(pix1);
            pixRenderBoxaArb(pix1, boxac1, 2, 255, 0, 0);
            pixRenderBoxaArb(pix1, boxac2, 2, 0, 255, 0);
            pixaAddPix(pixadb, pix1, L_INSERT);
        }

            /* First combine boxes in each set */
        boxa1 = boxaCombineOverlaps(boxac1, NULL);
        boxa2 = boxaCombineOverlaps(boxac2, NULL);

            /* Now combine boxes between sets */
        n1 = boxaGetCount(boxa1);
        n2 = boxaGetCount(boxa2);
        for (i = 0; i < n1; i++) {  /* 1 eats 2 */
            if ((box1 = boxaGetValidBox(boxa1, i, L_COPY)) == NULL)
                continue;
            for (j = 0; j < n2; j++) {
                if ((box2 = boxaGetValidBox(boxa2, j, L_COPY)) == NULL)
                    continue;
                boxIntersects(box1, box2, &overlap);
                boxCompareSize(box1, box2, L_SORT_BY_AREA, &bigger);
                if (overlap && (bigger == 1)) {
                    box3 = boxBoundingRegion(box1, box2);
                    boxaReplaceBox(boxa1, i, box3);
                    boxaReplaceBox(boxa2, j, boxCreate(0, 0, 0, 0));
                    boxDestroy(&box1);
                    box1 = boxCopy(box3);
                }
                boxDestroy(&box2);
            }
            boxDestroy(&box1);
        }
        for (i = 0; i < n2; i++) {  /* 2 eats 1 */
            if ((box2 = boxaGetValidBox(boxa2, i, L_COPY)) == NULL)
                continue;
            for (j = 0; j < n1; j++) {
                if ((box1 = boxaGetValidBox(boxa1, j, L_COPY)) == NULL)
                    continue;
                boxIntersects(box1, box2, &overlap);
                boxCompareSize(box2, box1, L_SORT_BY_AREA, &bigger);
                if (overlap && (bigger == 1)) {
                    box3 = boxBoundingRegion(box1, box2);
                    boxaReplaceBox(boxa2, i, box3);
                    boxaReplaceBox(boxa1, j, boxCreate(0, 0, 0, 0));
                    boxDestroy(&box2);
                    box2 = boxCopy(box3);
                }
                boxDestroy(&box1);
            }
            boxDestroy(&box2);
        }
        boxaDestroy(&boxac1);
        boxaDestroy(&boxac2);
        boxac1 = boxaSaveValid(boxa1, L_COPY);  /* remove invalid boxes */
        boxac2 = boxaSaveValid(boxa2, L_COPY);
        boxaDestroy(&boxa1);
        boxaDestroy(&boxa2);
        n1 = boxaGetCount(boxac1);
        n2 = boxaGetCount(boxac2);
        if (n1 == n1i && n2 == n2i) break;
        n1i = n1;
        n2i = n2;
        if (pixadb) {
            pix1 = pixCreate(w + 5, h + 5, 32);
            pixSetAll(pix1);
            pixRenderBoxaArb(pix1, boxac1, 2, 255, 0, 0);
            pixRenderBoxaArb(pix1, boxac2, 2, 0, 255, 0);
            pixaAddPix(pixadb, pix1, L_INSERT);
        }
    }

    if (pixadb)
        L_INFO("number of iterations: %d\n", procName, niters);
    *pboxad1 = boxac1;
    *pboxad2 = boxac2;
    return 0;
}