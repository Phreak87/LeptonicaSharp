﻿
l_ok
boxaContainedInBoxCount(BOXA     *boxa,
                        BOX      *box,
                        l_int32  *pcount)
{
l_int32  i, n, val;
BOX     *box1;

    PROCNAME("boxaContainedInBoxCount");

    if (!pcount)
        return ERROR_INT("&count not defined", procName, 1);
    *pcount = 0;
    if (!boxa)
        return ERROR_INT("boxa not defined", procName, 1);
    if (!box)
        return ERROR_INT("box not defined", procName, 1);
    if ((n = boxaGetCount(boxa)) == 0)
        return 0;

    for (i = 0; i < n; i++) {
        box1 = boxaGetBox(boxa, i, L_CLONE);
        boxContains(box, box1, &val);
        if (val == 1)
            (*pcount)++;
        boxDestroy(&box1);
    }
    return 0;
}