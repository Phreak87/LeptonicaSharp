﻿
l_ok
boxaContainedInBoxa(BOXA     *boxa1,
                    BOXA     *boxa2,
                    l_int32  *pcontained)
{
l_int32  i, j, n1, n2, cont, result;
BOX     *box1, *box2;

    PROCNAME("boxaContainedInBoxa");

    if (!pcontained)
        return ERROR_INT("&contained not defined", procName, 1);
    *pcontained = 0;
    if (!boxa1 || !boxa2)
        return ERROR_INT("boxa1 and boxa2 not both defined", procName, 1);

    n1 = boxaGetCount(boxa1);
    n2 = boxaGetCount(boxa2);
    for (i = 0; i < n2; i++) {
        box2 = boxaGetBox(boxa2, i, L_CLONE);
        cont = 0;
        for (j = 0; j < n1; j++) {
            box1 = boxaGetBox(boxa1, j, L_CLONE);
            boxContains(box1, box2, &result);
            boxDestroy(&box1);
            if (result) {
                cont = 1;
                break;
            }
        }
        boxDestroy(&box2);
        if (!cont) return 0;
    }

    *pcontained = 1;
    return 0;
}