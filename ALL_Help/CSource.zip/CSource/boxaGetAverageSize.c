﻿
l_ok
boxaGetAverageSize(BOXA       *boxa,
                   l_float32  *pw,
                   l_float32  *ph)
{
l_int32    i, n, bw, bh;
l_float32  sumw, sumh;

    PROCNAME("boxaGetAverageSize");

    if (pw) *pw = 0.0;
    if (ph) *ph = 0.0;
    if (!boxa)
        return ERROR_INT("boxa not defined", procName, 1);
    if ((n = boxaGetCount(boxa)) == 0)
        return ERROR_INT("boxa is empty", procName, 1);

    sumw = sumh = 0.0;
    for (i = 0; i < n; i++) {
        boxaGetBoxGeometry(boxa, i, NULL, NULL, &bw, &bh);
        sumw += bw;
        sumh += bh;
    }

    if (pw) *pw = sumw / n;
    if (ph) *ph = sumh / n;
    return 0;
}