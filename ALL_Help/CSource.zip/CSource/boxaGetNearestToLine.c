﻿
BOX *
boxaGetNearestToLine(BOXA    *boxa,
                     l_int32  x,
                     l_int32  y)
{
l_int32    i, n, minindex;
l_float32  dist, mindist, cx, cy;
BOX       *box;

    PROCNAME("boxaGetNearestToLine");

    if (!boxa)
        return (BOX *)ERROR_PTR("boxa not defined", procName, NULL);
    if ((n = boxaGetCount(boxa)) == 0)
        return (BOX *)ERROR_PTR("n = 0", procName, NULL);
    if (y >= 0 && x >= 0)
        return (BOX *)ERROR_PTR("either x or y must be < 0", procName, NULL);
    if (y < 0 && x < 0)
        return (BOX *)ERROR_PTR("either x or y must be >= 0", procName, NULL);

    mindist = 1000000000.;
    minindex = 0;
    for (i = 0; i < n; i++) {
        box = boxaGetBox(boxa, i, L_CLONE);
        boxGetCenter(box, &cx, &cy);
        if (x >= 0)
            dist = L_ABS(cx - (l_float32)x);
        else  /* y >= 0 */
            dist = L_ABS(cy - (l_float32)y);
        if (dist < mindist) {
            minindex = i;
            mindist = dist;
        }
        boxDestroy(&box);
    }

    return boxaGetBox(boxa, minindex, L_COPY);
}