﻿
BOX *
boxaSelectLargeULBox(BOXA      *boxas,
                     l_float32  areaslop,
                     l_int32    yslop)
{
l_int32    w, h, i, n, x1, y1, x2, y2, select;
l_float32  area, max_area;
BOX       *box;
BOXA      *boxa1, *boxa2, *boxa3;

    PROCNAME("boxaSelectLargeULBox");

    if (!boxas)
        return (BOX *)ERROR_PTR("boxas not defined", procName, NULL);
    if (boxaGetCount(boxas) == 0)
        return (BOX *)ERROR_PTR("no boxes in boxas", procName, NULL);
    if (areaslop < 0.0 || areaslop > 1.0)
        return (BOX *)ERROR_PTR("invalid value for areaslop", procName, NULL);
    yslop = L_MAX(0, yslop);

    boxa1 = boxaSort(boxas, L_SORT_BY_AREA, L_SORT_DECREASING, NULL);
    boxa2 = boxaSort(boxa1, L_SORT_BY_Y, L_SORT_INCREASING, NULL);
    n = boxaGetCount(boxa2);
    boxaGetBoxGeometry(boxa1, 0, NULL, NULL, &w, &h);  /* biggest box by area */
    max_area = (l_float32)(w * h);

        /* boxa3 collects all boxes eligible by area, sorted top-down */
    boxa3 = boxaCreate(4);
    for (i = 0; i < n; i++) {
        boxaGetBoxGeometry(boxa2, i, NULL, NULL, &w, &h);
        area = (l_float32)(w * h);
        if (area / max_area >= areaslop) {
            box = boxaGetBox(boxa2, i, L_COPY);
            boxaAddBox(boxa3, box, L_INSERT);
        }
    }

        /* Take the first (top-most box) unless the second (etc) has
         * nearly the same y value but a smaller x value. */
    n = boxaGetCount(boxa3);
    boxaGetBoxGeometry(boxa3, 0, &x1, &y1, NULL, NULL);
    select = 0;
    for (i = 1; i < n; i++) {
        boxaGetBoxGeometry(boxa3, i, &x2, &y2, NULL, NULL);
        if (y2 - y1 < yslop && x2 < x1) {
            select = i;
            x1 = x2;  /* but always compare against y1 */
        }
    }

    box = boxaGetBox(boxa3, select, L_COPY);
    boxaDestroy(&boxa1);
    boxaDestroy(&boxa2);
    boxaDestroy(&boxa3);
    return box;
}