﻿
l_ok
boxaWriteDebug(const char  *filename,
               BOXA        *boxa)
{
    PROCNAME("boxaWriteDebug");

    if (LeptDebugOK) {
        return boxaWrite(filename, boxa);
    } else {
        L_INFO("write to named temp file %s is disabled\n", procName, filename);
        return 0;
    }
}