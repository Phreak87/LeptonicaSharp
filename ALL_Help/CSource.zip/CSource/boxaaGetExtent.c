﻿
l_ok
boxaaGetExtent(BOXAA    *baa,
               l_int32  *pw,
               l_int32  *ph,
               BOX     **pbox,
               BOXA    **pboxa)
{
l_int32  i, n, x, y, w, h, xmax, ymax, xmin, ymin, found;
BOX     *box1;
BOXA    *boxa, *boxa1;

    PROCNAME("boxaaGetExtent");

    if (!pw && !ph && !pbox && !pboxa)
        return ERROR_INT("no ptrs defined", procName, 1);
    if (pw) *pw = 0;
    if (ph) *ph = 0;
    if (pbox) *pbox = NULL;
    if (pboxa) *pboxa = NULL;
    if (!baa)
        return ERROR_INT("baa not defined", procName, 1);

    n = boxaaGetCount(baa);
    if (n == 0)
        return ERROR_INT("no boxa in baa", procName, 1);

    boxa = boxaCreate(n);
    xmax = ymax = 0;
    xmin = ymin = 100000000;
    found = FALSE;
    for (i = 0; i < n; i++) {
        boxa1 = boxaaGetBoxa(baa, i, L_CLONE);
        boxaGetExtent(boxa1, NULL, NULL, &box1);
        boxaDestroy(&boxa1);
        boxGetGeometry(box1, &x, &y, &w, &h);
        if (w > 0 && h > 0) {  /* a valid extent box */
            found = TRUE;  /* found at least one valid extent box */
            xmin = L_MIN(xmin, x);
            ymin = L_MIN(ymin, y);
            xmax = L_MAX(xmax, x + w);
            ymax = L_MAX(ymax, y + h);
        }
        boxaAddBox(boxa, box1, L_INSERT);
    }
    if (found == FALSE)  /* no valid extent boxes */
        xmin = ymin = 0;

    if (pw) *pw = xmax;
    if (ph) *ph = ymax;
    if (pbox)
        *pbox = boxCreate(xmin, ymin, xmax - xmin, ymax - ymin);
    if (pboxa)
        *pboxa = boxa;
    else
        boxaDestroy(&boxa);
    return 0;
}