﻿
l_ok
composeRGBAPixel(l_int32    rval,
                 l_int32    gval,
                 l_int32    bval,
                 l_int32    aval,
                 l_uint32  *ppixel)
{
    PROCNAME("composeRGBAPixel");

    if (!ppixel)
        return ERROR_INT("&pixel not defined", procName, 1);

    *ppixel = (rval << L_RED_SHIFT) | (gval << L_GREEN_SHIFT) |
              (bval << L_BLUE_SHIFT) | aval;
    return 0;
}