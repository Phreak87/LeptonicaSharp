﻿
l_ok
convertFlateToPS(const char  *filein,
                 const char  *fileout,
                 const char  *operation,
                 l_int32      x,
                 l_int32      y,
                 l_int32      res,
                 l_float32    scale,
                 l_int32      pageno,
                 l_int32      endpage)
{
char    *outstr;
l_int32  nbytes, ret;

    PROCNAME("convertFlateToPS");

    if (!filein)
        return ERROR_INT("filein not defined", procName, 1);
    if (!fileout)
        return ERROR_INT("fileout not defined", procName, 1);
    if (strcmp(operation, "w") && strcmp(operation, "a"))
        return ERROR_INT("operation must be \"w\" or \"a\"", procName, 1);

    if (convertFlateToPSString(filein, &outstr, &nbytes, x, y, res, scale,
                               pageno, endpage))
        return ERROR_INT("ps string not made", procName, 1);

    ret = l_binaryWrite(fileout, operation, outstr, nbytes);
    LEPT_FREE(outstr);
    if (ret) L_ERROR("ps string not written to file\n", procName);
    return ret;
}