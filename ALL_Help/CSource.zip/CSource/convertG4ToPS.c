﻿
l_ok
convertG4ToPS(const char  *filein,
              const char  *fileout,
              const char  *operation,
              l_int32      x,
              l_int32      y,
              l_int32      res,
              l_float32    scale,
              l_int32      pageno,
              l_int32      maskflag,
              l_int32      endpage)
{
char    *outstr;
l_int32  nbytes;

    PROCNAME("convertG4ToPS");

    if (!filein)
        return ERROR_INT("filein not defined", procName, 1);
    if (!fileout)
        return ERROR_INT("fileout not defined", procName, 1);
    if (strcmp(operation, "w") && strcmp(operation, "a"))
        return ERROR_INT("operation must be \"w\" or \"a\"", procName, 1);

    if (convertG4ToPSString(filein, &outstr, &nbytes, x, y, res, scale,
                            pageno, maskflag, endpage))
        return ERROR_INT("ps string not made", procName, 1);

    if (l_binaryWrite(fileout, operation, outstr, nbytes))
        return ERROR_INT("ps string not written to file", procName, 1);

    LEPT_FREE(outstr);
    return 0;
}