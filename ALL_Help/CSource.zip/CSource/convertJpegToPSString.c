﻿
l_ok
convertJpegToPSString(const char  *filein,
                      char       **poutstr,
                      l_int32     *pnbytes,
                      l_int32      x,
                      l_int32      y,
                      l_int32      res,
                      l_float32    scale,
                      l_int32      pageno,
                      l_int32      endpage)
{
char         *outstr;
l_float32     xpt, ypt, wpt, hpt;
L_COMP_DATA  *cid;

    PROCNAME("convertJpegToPSString");

    if (!poutstr)
        return ERROR_INT("&outstr not defined", procName, 1);
    if (!pnbytes)
        return ERROR_INT("&nbytes not defined", procName, 1);
    *poutstr = NULL;
    *pnbytes = 0;
    if (!filein)
        return ERROR_INT("filein not defined", procName, 1);

        /* Generate the ascii encoded jpeg data */
    if ((cid = l_generateJpegData(filein, 1)) == NULL)
        return ERROR_INT("jpeg data not made", procName, 1);

        /* Get scaled location in pts.  Guess the input scan resolution
         * based on the input parameter %res, the resolution data in
         * the pix, and the size of the image. */
    if (scale == 0.0)
        scale = 1.0;
    if (res <= 0) {
        if (cid->res > 0)
            res = cid->res;
        else
            res = DEFAULT_INPUT_RES;
    }

        /* Get scaled location in pts */
    if (scale == 0.0)
        scale = 1.0;
    xpt = scale * x * 72. / res;
    ypt = scale * y * 72. / res;
    wpt = scale * cid->w * 72. / res;
    hpt = scale * cid->h * 72. / res;

    if (pageno == 0)
        pageno = 1;

#if  DEBUG_JPEG
    fprintf(stderr, "w = %d, h = %d, bps = %d, spp = %d\n",
            cid->w, cid->h, cid->bps, cid->spp);
    fprintf(stderr, "comp bytes = %ld, nbytes85 = %ld, ratio = %5.3f\n",
            (unsigned long)cid->nbytescomp, (unsigned long)cid->nbytes85,
           (l_float32)cid->nbytes85 / (l_float32)cid->nbytescomp);
    fprintf(stderr, "xpt = %7.2f, ypt = %7.2f, wpt = %7.2f, hpt = %7.2f\n",
             xpt, ypt, wpt, hpt);
#endif   /* DEBUG_JPEG */

        /* Generate the PS */
    outstr = generateJpegPS(NULL, cid, xpt, ypt, wpt, hpt, pageno, endpage);
    if (!outstr)
        return ERROR_INT("outstr not made", procName, 1);
    *poutstr = outstr;
    *pnbytes = strlen(outstr);
    l_CIDataDestroy(&cid);
    return 0;
}