﻿
l_ok
convertLABToRGB(l_float32  flval,
                l_float32  faval,
                l_float32  fbval,
                l_int32   *prval,
                l_int32   *pgval,
                l_int32   *pbval)
{
l_float32  fxval, fyval, fzval;

    PROCNAME("convertLABToRGB");

    if (prval) *prval = 0;
    if (pgval) *pgval = 0;
    if (pbval) *pbval = 0;
    if (!prval || !pgval || !pbval)
        return ERROR_INT("&rval, &gval, &bval not all defined", procName, 1);

    convertLABToXYZ(flval, faval, fbval, &fxval, &fyval, &fzval);
    convertXYZToRGB(fxval, fyval, fzval, 0, prval, pgval, pbval);
    return 0;
}