﻿
l_uint16
convertOnBigEnd16(l_uint16  shortin)
{
    return  shortin;
}