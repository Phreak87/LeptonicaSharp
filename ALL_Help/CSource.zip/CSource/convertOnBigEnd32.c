﻿
l_uint32
convertOnBigEnd32(l_uint32  wordin)
{
    return wordin;
}