﻿
PTA *
convertPtaLineTo4cc(PTA  *ptas)
{
l_int32  i, n, x, y, xp, yp;
PTA     *ptad;

    PROCNAME("convertPtaLineTo4cc");

    if (!ptas)
        return (PTA *)ERROR_PTR("ptas not defined", procName, NULL);

    n = ptaGetCount(ptas);
    ptad = ptaCreate(n);
    ptaGetIPt(ptas, 0, &xp, &yp);
    ptaAddPt(ptad, xp, yp);
    for (i = 1; i < n; i++) {
        ptaGetIPt(ptas, i, &x, &y);
        if (x != xp && y != yp)  /* diagonal */
            ptaAddPt(ptad, x, yp);
        ptaAddPt(ptad, x, y);
        xp = x;
        yp = y;
    }

    return ptad;
}