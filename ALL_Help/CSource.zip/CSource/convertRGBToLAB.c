﻿
l_ok
convertRGBToLAB(l_int32     rval,
                l_int32     gval,
                l_int32     bval,
                l_float32  *pflval,
                l_float32  *pfaval,
                l_float32  *pfbval)
{
l_float32  fxval, fyval, fzval;

    PROCNAME("convertRGBToLAB");

    if (pflval) *pflval = 0.0;
    if (pfaval) *pfaval = 0.0;
    if (pfbval) *pfbval = 0.0;
    if (!pflval || !pfaval || !pfbval)
        return ERROR_INT("&flval, &faval, &fbval not all defined", procName, 1);

    convertRGBToXYZ(rval, gval, bval, &fxval, &fyval, &fzval);
    convertXYZToLAB(fxval, fyval, fzval, pflval, pfaval, pfbval);
    return 0;
}