﻿
l_ok
convertRGBToXYZ(l_int32     rval,
                l_int32     gval,
                l_int32     bval,
                l_float32  *pfxval,
                l_float32  *pfyval,
                l_float32  *pfzval)
{
    PROCNAME("convertRGBToXYZ");

    if (pfxval) *pfxval = 0.0;
    if (pfyval) *pfyval = 0.0;
    if (pfzval) *pfzval = 0.0;
    if (!pfxval || !pfyval || !pfzval)
        return ERROR_INT("&xval, &yval, &zval not all defined", procName, 1);

    *pfxval = 0.4125 * rval + 0.3576 * gval + 0.1804 * bval;
    *pfyval = 0.2127 * rval + 0.7152 * gval + 0.0722 * bval;
    *pfzval = 0.0193 * rval + 0.1192 * gval + 0.9502 * bval;
    return 0;
}