﻿
l_ok
convertTiffMultipageToPS(const char  *filein,
                         const char  *fileout,
                         l_float32    fillfract)
{
char      *tempfile;
l_int32    i, npages, w, h, istiff;
l_float32  scale;
PIX       *pix, *pixs;
FILE      *fp;

    PROCNAME("convertTiffMultipageToPS");

    if (!filein)
        return ERROR_INT("filein not defined", procName, 1);
    if (!fileout)
        return ERROR_INT("fileout not defined", procName, 1);

    if ((fp = fopenReadStream(filein)) == NULL)
        return ERROR_INT("file not found", procName, 1);
    istiff = fileFormatIsTiff(fp);
    if (!istiff) {
        fclose(fp);
        return ERROR_INT("file not tiff format", procName, 1);
    }
    tiffGetCount(fp, &npages);
    fclose(fp);

    if (fillfract == 0.0)
        fillfract = DEFAULT_FILL_FRACTION;

    for (i = 0; i < npages; i++) {
        if ((pix = pixReadTiff(filein, i)) == NULL)
            return ERROR_INT("pix not made", procName, 1);

        pixGetDimensions(pix, &w, &h, NULL);
        if (w == 1728 && h < w)   /* it's a std res fax */
            pixs = pixScale(pix, 1.0, 2.0);
        else
            pixs = pixClone(pix);

        tempfile = l_makeTempFilename();
        pixWrite(tempfile, pixs, IFF_TIFF_G4);
        scale = L_MIN(fillfract * 2550 / w, fillfract * 3300 / h);
        if (i == 0)
            convertG4ToPS(tempfile, fileout, "w", 0, 0, 300, scale,
                          i + 1, FALSE, TRUE);
        else
            convertG4ToPS(tempfile, fileout, "a", 0, 0, 300, scale,
                          i + 1, FALSE, TRUE);
        lept_rmfile(tempfile);
        LEPT_FREE(tempfile);
        pixDestroy(&pix);
        pixDestroy(&pixs);
    }

    return 0;
}