﻿
l_ok
convertUnscaledToPdfData(const char  *fname,
                         const char  *title,
                         l_uint8    **pdata,
                         size_t      *pnbytes)
{
const char   *pdftitle = NULL;
char         *tail = NULL;
l_int32       format;
L_COMP_DATA  *cid;

    PROCNAME("convertUnscaledToPdfData");

    if (!pdata)
        return ERROR_INT("&data not defined", procName, 1);
    *pdata = NULL;
    if (!pnbytes)
        return ERROR_INT("&nbytes not defined", procName, 1);
    *pnbytes = 0;
    if (!fname)
        return ERROR_INT("fname not defined", procName, 1);

    findFileFormat(fname, &format);
    if (format == IFF_UNKNOWN) {
        L_WARNING("file %s format is unknown; skip\n", procName, fname);
        return 1;
    }
    if (format == IFF_PS || format == IFF_LPDF) {
        L_WARNING("file %s format is %d; skip\n", procName, fname, format);
        return 1;
    }

        /* Generate the image data required for pdf generation, always
         * in binary (not ascii85) coding; jpeg files are never transcoded.  */
    l_generateCIDataForPdf(fname, NULL, 0, &cid);
    if (!cid) {
        L_ERROR("file %s format is %d; unreadable\n", procName, fname, format);
        return 1;
    }

        /* If %title == NULL, use the tail of %fname. */
    if (title) {
        pdftitle = title;
    } else {
        splitPathAtDirectory(fname, NULL, &tail);
        pdftitle = tail;
    }

        /* Generate the pdf string for this page (image).  This destroys
         * the cid by attaching it to an lpd and destroying the lpd. */
    cidConvertToPdfData(cid, pdftitle, pdata, pnbytes);
    LEPT_FREE(tail);
    return 0;
}