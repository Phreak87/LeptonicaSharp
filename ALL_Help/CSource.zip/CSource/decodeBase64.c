﻿
l_uint8 *
decodeBase64(const char  *inarray,
             l_int32      insize,
             l_int32     *poutsize)
{
char      inchar;
l_uint8  *bytea;
l_uint8   array3[3], array4[4];
l_int32  *rtable64;
l_int32   i, j, outsize, in_index, out_index;

    PROCNAME("decodeBase64");

    if (!poutsize)
        return (l_uint8 *)ERROR_PTR("&outsize not defined", procName, NULL);
    *poutsize = 0;
    if (!inarray)
        return (l_uint8 *)ERROR_PTR("inarray not defined", procName, NULL);
    if (insize <= 0)
        return (l_uint8 *)ERROR_PTR("insize not > 0", procName, NULL);

        /* Validate the input data */
    for (i = 0; i < insize; i++) {
        inchar = inarray[i];
        if (inchar == '\n') continue;
        if (isBase64(inchar) == 0 && inchar != '=')
            return (l_uint8 *)ERROR_PTR("invalid char in inarray",
                                        procName, NULL);
    }

        /* The input array typically is made with a newline every
         * MAX_BASE64_LINE input bytes.  However, as a printed string, the
         * newlines would be stripped.  So when we allocate the output
         * array, assume the input array is all data, but strip
         * out the newlines during decoding.  This guarantees that
         * the allocated array is large enough. */
    outsize = 3 * ((insize + 3) / 4) + 4;
    if ((bytea = (l_uint8 *)LEPT_CALLOC(outsize, sizeof(l_uint8))) == NULL)
        return (l_uint8 *)ERROR_PTR("bytea not made", procName, NULL);

        /* The number of encoded input data bytes is always a multiple of 4.
         * Read all the data, until you reach either the end or
         * the first pad character '='.  The data is processed in
         * units of 4 input bytes, generating 3 output decoded bytes
         * of binary data.  Newlines are ignored.  If there are no
         * pad bytes, i == 0 at the end of this section. */
    rtable64 = genReverseTab64();
    i = in_index = out_index = 0;
    for (in_index = 0; in_index < insize; in_index++) {
        inchar = inarray[in_index];
        if (inchar == '\n') continue;
        if (inchar == '=') break;
        array4[i++] = rtable64[(unsigned char)inchar];
        if (i < 4) {
            continue;
        } else {  /* i == 4; convert 4 to 3 and save */
            byteConvert4to3(array4, array3);
            for (j = 0; j < 3; j++)
                bytea[out_index++] = array3[j];
            i = 0;
        }
    }

        /* If i > 0, we ran into pad bytes ('=').  If i == 2, there are
         * two input pad bytes and one output data byte.  If i == 3,
         * there is one input pad byte and two output data bytes. */
    if (i > 0) {
        for (j = i; j < 4; j++)
            array4[j] = '\0';  /* zero the remaining input bytes */
        byteConvert4to3(array4, array3);
        for (j = 0; j < i - 1; j++)
            bytea[out_index++] = array3[j];
    }
    *poutsize = out_index;

    LEPT_FREE(rtable64);
    return bytea;
}