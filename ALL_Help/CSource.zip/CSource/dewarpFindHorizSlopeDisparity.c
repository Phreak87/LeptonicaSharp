﻿
l_ok
dewarpFindHorizSlopeDisparity(L_DEWARP  *dew,
                              PIX       *pixb,
                              l_float32  fractthresh,
                              l_int32    parity)
{
l_int32    i, j, x, n1, n2, nb, ne, count, w, h, ival, prev;
l_int32    istart, iend, first, last, x0, x1, nx, ny;
l_float32  fract, delta, sum, aveval, fval, del, denom;
l_float32  ca, cb, cc, cd, ce, y;
BOX       *box;
BOXA      *boxa1, *boxa2;
NUMA      *na1, *na2, *na3, *na4, *nasum;
PIX       *pix1;
PTA       *pta1;
FPIX      *fpix;

    PROCNAME("dewarpFindHorizSlopeDisparity");

    if (!dew)
        return ERROR_INT("dew not defined", procName, 1);
    if (!dew->vvalid || !dew->hvalid)
        return ERROR_INT("invalid vert or horiz disparity model", procName, 1);
    if (!pixb || pixGetDepth(pixb) != 1)
        return ERROR_INT("pixb not defined or not 1 bpp", procName, 1);

    if (dew->debug) L_INFO("finding slope horizontal disparity\n", procName);

        /* Find the bounding boxes of the vertical strokes; remove noise */
    pix1 = pixMorphSequence(pixb, "o1.10", 0);
    pixDisplay(pix1, 100, 100);
    boxa1 = pixConnCompBB(pix1, 4);
    boxa2 = boxaSelectBySize(boxa1, 0, 5, L_SELECT_HEIGHT, L_SELECT_IF_GT,
                             NULL);
    nb = boxaGetCount(boxa2);
    fprintf(stderr, "number of components: %d\n", nb);
    boxaDestroy(&boxa1);

        /* Estimate the horizontal density of vertical strokes */
    na1 = numaCreate(0);
    numaSetParameters(na1, 0, 25);
    pixGetDimensions(pixb, &w, &h, NULL);
    for (x = 0; x + 50 < w; x += 25) {
        box = boxCreate(x, 0, 50, h);
        boxaContainedInBoxCount(boxa2, box, &count);
        numaAddNumber(na1, count);
        boxDestroy(&box);
    }
    if (dew->debug) {
        lept_mkdir("lept/dew");
        gplotSimple1(na1, GPLOT_PNG, "/tmp/lept/dew/0091", NULL);
        lept_mv("/tmp/lept/dew/0091.png", "lept/dewmod", NULL, NULL);
        pixWriteDebug("/tmp/lept/dewmod/0090.png", pix1, IFF_PNG);
    }
    pixDestroy(&pix1);
    boxaDestroy(&boxa2);

        /* Find the left and right end local maxima; if the difference
         * is small, quit.  */
    n1 = numaGetCount(na1);
    prev = 0;
    istart = 0;
    first = 0;
    for (i = 0; i < n1; i++) {
        numaGetIValue(na1, i, &ival);
        if (ival >= prev) {
            prev = ival;
            continue;
        } else {
            first = prev;
            istart = i - 1;
            break;
        }
    }
    prev = 0;
    last = 0;
    iend = n1 - 1;
    for (i = n1 - 1; i >= 0; i--) {
        numaGetIValue(na1, i, &ival);
        if (ival >= prev) {
            prev = ival;
            continue;
        } else {
            last = prev;
            iend = i + 1;
            break;
        }
    }
    na2 = numaClipToInterval(na1, istart, iend);
    numaDestroy(&na1);
    n2 = numaGetCount(na2);
    delta = (parity == 0) ? last - first : first - last;
    denom = L_MAX(1.0, (l_float32)(L_MIN(first, last)));
    fract = (l_float32)delta / denom;
    if (dew->debug) {
        L_INFO("Slope-disparity: first = %d, last = %d, fract = %7.3f\n",
               procName, first, last, fract);
        gplotSimple1(na2, GPLOT_PNG, "/tmp/lept/dew/0092", NULL);
        lept_mv("/tmp/lept/dew/0092.png", "lept/dewmod", NULL, NULL);
    }
    if (fract < fractthresh) {
        L_INFO("Small slope-disparity: first = %d, last = %d, fract = %7.3f\n",
               procName, first, last, fract);
        numaDestroy(&na2);
        return 0;
    }

        /* Find the density far from the binding, and normalize to 1.  */
    ne = n2 - n2 % 2;
    if (parity == 0)
        numaGetSumOnInterval(na2, 0, ne / 2 - 1, &sum);
    else  /* parity == 1 */
        numaGetSumOnInterval(na2, ne / 2, ne - 1, &sum);
    denom = L_MAX(1.0, (l_float32)(ne / 2));
    aveval = sum / denom;
    na3 = numaMakeConstant(aveval, n2);
    numaArithOp(na2, na2, na3, L_ARITH_DIVIDE);
    numaDestroy(&na3);
    if (dew->debug) {
        L_INFO("Average background density: %5.1f\n", procName, aveval);
        gplotSimple1(na2, GPLOT_PNG, "/tmp/lept/dew/0093", NULL);
        lept_mv("/tmp/lept/dew/0093.png", "lept/dewmod", NULL, NULL);
    }

        /* Fit the normalized density curve to a quartic */
    pta1 = numaConvertToPta1(na2);
    ptaWriteStream(stderr, pta1, 0);
/*    ptaGetQuadraticLSF(pta1, NULL, NULL, NULL, &na3); */
    ptaGetQuarticLSF(pta1, &ca, &cb, &cc, &cd, &ce, &na3);
    ptaGetArrays(pta1, &na4, NULL);
    if (dew->debug) {
        gplotSimpleXY1(na4, na3, GPLOT_LINES, GPLOT_PNG,
                       "/tmp/lept/dew/0094", NULL);
        lept_mv("/tmp/lept/dew/0094.png", "lept/dewmod", NULL, NULL);
    }
    ptaDestroy(&pta1);

        /* Integrate from the high point down to 1 (or v.v) to get the
         * disparity needed to make the density constant. */
    nasum = numaMakeConstant(0, w);  /* area under the curve above 1.0 */
    if (parity == 0) {
        for (i = n2 - 1; i >= 0; i--) {
            numaGetFValue(na3, i, &fval);
            if (fval < 1.0) break;
        }
        numaGetIValue(na4, i + 1, &x0);
        numaGetIValue(na4, n2 - 1, &x1);
        numaSetParameters(nasum, x0, 1);
        sum = 0.0;
        for (x = x0; x < x1; x++) {
            applyQuarticFit(ca, cb, cc, cd, ce, (l_float32)x, &y);
            sum += (y - 1.0);
            numaReplaceNumber(nasum, x, sum);
        }
        for (x = x1; x < w; x++)
            numaReplaceNumber(nasum, x, sum);
    } else {  /* parity == 1 */
        for (i = 0; i < n2; i++) {
            numaGetFValue(na3, i, &fval);
            if (fval < 1.0) break;
        }
        numaGetIValue(na4, 0, &x0);
        numaGetIValue(na4, i - 1, &x1);
        numaSetParameters(nasum, x0, 1);
        sum = 0.0;
        for (x = x1; x >= x0; x--) {
            applyQuarticFit(ca, cb, cc, cd, ce, (l_float32)x, &y);
            sum += (y - 1.0);
            numaReplaceNumber(nasum, x, sum);
        }
        for (x = x0; x >= 0; x--)
            numaReplaceNumber(nasum, x, sum);
    }

        /* Save the result in a fpix at the specified subsampling  */
    nx = dew->nx;
    ny = dew->ny;
    fpix = fpixCreate(nx, ny);
    del = (l_float32)w / (l_float32)nx;
    for (i = 0; i < ny; i++) {
        for (j = 0; j < nx; j++) {
            x = del * j;
            numaGetFValue(nasum, x, &fval);
            fpixSetPixel(fpix, j, i, fval);
        }
    }
    dew->sampydispar = fpix;
    dew->ysuccess = 1;

    numaDestroy(&na2);
    numaDestroy(&na3);
    numaDestroy(&na4);
    numaDestroy(&nasum);
    return 0;
}