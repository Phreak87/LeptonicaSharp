﻿
L_DEWARP  *
dewarpReadMem(const l_uint8  *data,
              size_t          size)
{
FILE      *fp;
L_DEWARP  *dew;

    PROCNAME("dewarpReadMem");

    if (!data)
        return (L_DEWARP *)ERROR_PTR("data not defined", procName, NULL);
    if ((fp = fopenReadFromMemory(data, size)) == NULL)
        return (L_DEWARP *)ERROR_PTR("stream not opened", procName, NULL);

    dew = dewarpReadStream(fp);
    fclose(fp);
    if (!dew) L_ERROR("dew not read\n", procName);
    return dew;
}