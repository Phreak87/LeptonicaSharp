﻿
l_ok
dewarpWrite(const char  *filename,
            L_DEWARP    *dew)
{
l_int32  ret;
FILE    *fp;

    PROCNAME("dewarpWrite");

    if (!filename)
        return ERROR_INT("filename not defined", procName, 1);
    if (!dew)
        return ERROR_INT("dew not defined", procName, 1);

    if ((fp = fopenWriteStream(filename, "wb")) == NULL)
        return ERROR_INT("stream not opened", procName, 1);
    ret = dewarpWriteStream(fp, dew);
    fclose(fp);
    if (ret)
        return ERROR_INT("dew not written to stream", procName, 1);
    return 0;
}