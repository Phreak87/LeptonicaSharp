﻿
l_ok
dewarpaApplyDisparity(L_DEWARPA   *dewa,
                      l_int32      pageno,
                      PIX         *pixs,
                      l_int32      grayin,
                      l_int32      x,
                      l_int32      y,
                      PIX        **ppixd,
                      const char  *debugfile)
{
L_DEWARP  *dew1, *dew;
PIX       *pixv, *pixh;

    PROCNAME("dewarpaApplyDisparity");

        /* Initialize the output with the input, so we'll have that
         * in case we can't apply the page model. */
    if (!ppixd)
        return ERROR_INT("&pixd not defined", procName, 1);
    *ppixd = pixClone(pixs);
    if (grayin > 255) {
        L_WARNING("invalid grayin = %d; clipping at 255\n", procName, grayin);
        grayin = 255;
    }

        /* Find the appropriate dew to use and fully populate its array(s) */
    if (dewarpaApplyInit(dewa, pageno, pixs, x, y, &dew, debugfile))
        return ERROR_INT("no model available", procName, 1);

        /* Correct for vertical disparity and save the result */
    if ((pixv = pixApplyVertDisparity(dew, pixs, grayin)) == NULL) {
        dewarpMinimize(dew);
        return ERROR_INT("pixv not made", procName, 1);
    }
    pixDestroy(ppixd);
    *ppixd = pixv;
    if (debugfile) {
        pixDisplayWithTitle(pixv, 300, 0, "pixv", 1);
        lept_rmdir("lept/dewapply");  /* remove previous images */
        lept_mkdir("lept/dewapply");
        pixWriteDebug("/tmp/lept/dewapply/001.png", pixs, IFF_PNG);
        pixWriteDebug("/tmp/lept/dewapply/002.png", pixv, IFF_PNG);
    }

        /* Optionally, correct for horizontal disparity */
    if (dewa->useboth && dew->hsuccess && !dew->skip_horiz) {
        if (dew->hvalid == FALSE) {
            L_INFO("invalid horiz model for page %d\n", procName, pageno);
        } else {
            if ((pixh = pixApplyHorizDisparity(dew, pixv, grayin)) != NULL) {
                pixDestroy(ppixd);
                *ppixd = pixh;
                if (debugfile) {
                    pixDisplayWithTitle(pixh, 600, 0, "pixh", 1);
                    pixWriteDebug("/tmp/lept/dewapply/003.png", pixh, IFF_PNG);
                }
            } else {
                L_ERROR("horiz disparity failed on page %d\n",
                        procName, pageno);
            }
        }
    }

    if (debugfile) {
        dew1 = dewarpaGetDewarp(dewa, pageno);
        dewarpDebug(dew1, "lept/dewapply", 0);
        convertFilesToPdf("/tmp/lept/dewapply", NULL, 250, 1.0, 0, 0,
                         "Dewarp Apply Disparity", debugfile);
        fprintf(stderr, "pdf file: %s\n", debugfile);
    }

        /* Get rid of the large full res disparity arrays */
    dewarpMinimize(dew);

    return 0;
}