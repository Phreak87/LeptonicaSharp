﻿
L_DEWARP *
dewarpaGetDewarp(L_DEWARPA  *dewa,
                 l_int32     index)
{
    PROCNAME("dewarpaGetDewarp");

    if (!dewa)
        return (L_DEWARP *)ERROR_PTR("dewa not defined", procName, NULL);
    if (index < 0 || index > dewa->maxpage) {
        L_ERROR("index = %d is invalid; max index = %d\n",
                procName, index, dewa->maxpage);
        return NULL;
    }

    return dewa->dewarp[index];
}