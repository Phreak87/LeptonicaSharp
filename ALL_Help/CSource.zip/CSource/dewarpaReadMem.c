﻿
L_DEWARPA  *
dewarpaReadMem(const l_uint8  *data,
               size_t          size)
{
FILE       *fp;
L_DEWARPA  *dewa;

    PROCNAME("dewarpaReadMem");

    if (!data)
        return (L_DEWARPA *)ERROR_PTR("data not defined", procName, NULL);
    if ((fp = fopenReadFromMemory(data, size)) == NULL)
        return (L_DEWARPA *)ERROR_PTR("stream not opened", procName, NULL);

    dewa = dewarpaReadStream(fp);
    fclose(fp);
    if (!dewa) L_ERROR("dewa not read\n", procName);
    return dewa;
}