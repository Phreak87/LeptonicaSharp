﻿
l_ok
dewarpaSetCheckColumns(L_DEWARPA  *dewa,
                       l_int32     check_columns)
{
    PROCNAME("dewarpaSetCheckColumns");

    if (!dewa)
        return ERROR_INT("dewa not defined", procName, 1);

    dewa->check_columns = check_columns;
    return 0;
}