﻿
l_ok
dewarpaUseBothArrays(L_DEWARPA  *dewa,
                     l_int32     useboth)
{
    PROCNAME("dewarpaUseBothArrays");

    if (!dewa)
        return ERROR_INT("dewa not defined", procName, 1);

    dewa->useboth = useboth;
    dewa->modelsready = 0;  /* force validation */
    return 0;
}