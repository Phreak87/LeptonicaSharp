﻿
l_ok
dewarpaWrite(const char  *filename,
             L_DEWARPA   *dewa)
{
l_int32  ret;
FILE    *fp;

    PROCNAME("dewarpaWrite");

    if (!filename)
        return ERROR_INT("filename not defined", procName, 1);
    if (!dewa)
        return ERROR_INT("dewa not defined", procName, 1);

    if ((fp = fopenWriteStream(filename, "wb")) == NULL)
        return ERROR_INT("stream not opened", procName, 1);
    ret = dewarpaWriteStream(fp, dewa);
    fclose(fp);
    if (ret)
        return ERROR_INT("dewa not written to stream", procName, 1);
    return 0;
}