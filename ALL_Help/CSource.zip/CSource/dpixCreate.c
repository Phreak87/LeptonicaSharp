﻿
DPIX *
dpixCreate(l_int32  width,
           l_int32  height)
{
l_float64  *data;
l_uint64    npix64;
DPIX       *dpix;

    PROCNAME("dpixCreate");

    if (width <= 0)
        return (DPIX *)ERROR_PTR("width must be > 0", procName, NULL);
    if (height <= 0)
        return (DPIX *)ERROR_PTR("height must be > 0", procName, NULL);

        /* Avoid overflow in malloc arg, malicious or otherwise */
    npix64 = (l_uint64)width * (l_uint64)height;   /* # of 8 byte pixels */
    if (npix64 >= (1LL << 28)) {
        L_ERROR("requested w = %d, h = %d\n", procName, width, height);
        return (DPIX *)ERROR_PTR("requested bytes >= 2^31", procName, NULL);
    }

    dpix = (DPIX *)LEPT_CALLOC(1, sizeof(DPIX));
    dpixSetDimensions(dpix, width, height);
    dpixSetWpl(dpix, width);  /* 8 byte words */
    dpix->refcount = 1;

    data = (l_float64 *)LEPT_CALLOC(width * height, sizeof(l_float64));
    if (!data) {
        dpixDestroy(&dpix);
        return (DPIX *)ERROR_PTR("calloc fail for data", procName, NULL);
    }
    dpixSetData(dpix, data);
    return dpix;
}