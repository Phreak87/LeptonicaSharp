﻿
l_ok
dpixGetDimensions(DPIX     *dpix,
                  l_int32  *pw,
                  l_int32  *ph)
{
    PROCNAME("dpixGetDimensions");

    if (!pw && !ph)
        return ERROR_INT("no return val requested", procName, 1);
    if (pw) *pw = 0;
    if (ph) *ph = 0;
    if (!dpix)
        return ERROR_INT("dpix not defined", procName, 1);
    if (pw) *pw = dpix->w;
    if (ph) *ph = dpix->h;
    return 0;
}