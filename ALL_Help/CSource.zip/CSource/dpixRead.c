﻿
DPIX *
dpixRead(const char  *filename)
{
FILE  *fp;
DPIX  *dpix;

    PROCNAME("dpixRead");

    if (!filename)
        return (DPIX *)ERROR_PTR("filename not defined", procName, NULL);

    if ((fp = fopenReadStream(filename)) == NULL)
        return (DPIX *)ERROR_PTR("stream not opened", procName, NULL);
    dpix = dpixReadStream(fp);
    fclose(fp);
    if (!dpix)
        return (DPIX *)ERROR_PTR("dpix not read", procName, NULL);
    return dpix;
}