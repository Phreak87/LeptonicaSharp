﻿
char *
encodeBase64(l_uint8  *inarray,
             l_int32   insize,
             l_int32  *poutsize)
{
char     *chara;
l_uint8  *bytea;
l_uint8   array3[3], array4[4];
l_int32   outsize, i, j, index, linecount;

    PROCNAME("encodeBase64");

    if (!poutsize)
        return (char *)ERROR_PTR("&outsize not defined", procName, NULL);
    *poutsize = 0;
    if (!inarray)
        return (char *)ERROR_PTR("inarray not defined", procName, NULL);
    if (insize <= 0)
        return (char *)ERROR_PTR("insize not > 0", procName, NULL);

        /* The output array is padded to a multiple of 4 bytes, not
         * counting the newlines.  We just need to allocate a large
         * enough array, and add 4 bytes to make sure it is big enough. */
    outsize = 4 * ((insize + 2) / 3);  /* without newlines */
    outsize += outsize / MAX_BASE64_LINE + 4;  /* with the newlines */
    if ((chara = (char *)LEPT_CALLOC(outsize, sizeof(char))) == NULL)
        return (char *)ERROR_PTR("chara not made", procName, NULL);

        /* Read all the input data, and convert in sets of 3 input
         * bytes --> 4 output bytes. */
    i = index = linecount = 0;
    bytea = inarray;
    while (insize--) {
        if (linecount == MAX_BASE64_LINE) {
            chara[index++] = '\n';
            linecount = 0;
        }
        array3[i++] = *bytea++;
        if (i == 3) {  /* convert 3 to 4 and save */
            byteConvert3to4(array3, array4);
            for (j = 0; j < 4; j++)
                chara[index++] = tablechar64[array4[j]];
            i = 0;
            linecount += 4;
        }
    }

        /* Suppose 1 or 2 bytes has been read but not yet processed.
         * If 1 byte has been read, this will generate 2 bytes of
         * output, with 6 bits to the first byte and 2 bits to the second.
         * We will add two bytes of '=' for padding.
         * If 2 bytes has been read, this will generate 3 bytes of output,
         * with 6 bits to the first 2 bytes and 4 bits to the third, and
         * we add a fourth padding byte ('='). */
    if (i > 0) {  /* left-over 1 or 2 input bytes */
        for (j = i; j < 3; j++)
            array3[j] = '\0';  /* zero the remaining input bytes */
        byteConvert3to4(array3, array4);
        for (j = 0; j <= i; j++)
            chara[index++] = tablechar64[array4[j]];
        for (j = i + 1; j < 4; j++)
            chara[index++] = '=';
    }
    *poutsize = index;

    return chara;
}