﻿
l_ok
fgetPngColormapInfo(FILE      *fp,
                    PIXCMAP  **pcmap,
                    l_int32   *ptransparency)
{
l_int32      i, cindex, rval, gval, bval, num_palette, num_trans;
png_byte     bit_depth, color_type;
png_bytep    trans;
png_colorp   palette;
png_structp  png_ptr;
png_infop    info_ptr;

    PROCNAME("fgetPngColormapInfo");

    if (pcmap) *pcmap = NULL;
    if (ptransparency) *ptransparency = 0;
    if (!pcmap && !ptransparency)
        return ERROR_INT("no output defined", procName, 1);
    if (!fp)
        return ERROR_INT("stream not opened", procName, 1);

       /* Make the two required structs */
    if ((png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING,
                   (png_voidp)NULL, NULL, NULL)) == NULL)
        return ERROR_INT("png_ptr not made", procName, 1);
    if ((info_ptr = png_create_info_struct(png_ptr)) == NULL) {
        png_destroy_read_struct(&png_ptr, (png_infopp)NULL, (png_infopp)NULL);
        return ERROR_INT("info_ptr not made", procName, 1);
    }

        /* Set up png setjmp error handling.
         * Without this, an error calls exit. */
    if (setjmp(png_jmpbuf(png_ptr))) {
        png_destroy_read_struct(&png_ptr, &info_ptr, NULL);
        if (pcmap && *pcmap) pixcmapDestroy(pcmap);
        return ERROR_INT("internal png error", procName, 1);
    }

        /* Read the metadata and check if there is a colormap */
    rewind(fp);
    png_init_io(png_ptr, fp);
    png_read_info(png_ptr, info_ptr);
    color_type = png_get_color_type(png_ptr, info_ptr);
    if (color_type != PNG_COLOR_TYPE_PALETTE &&
        color_type != PNG_COLOR_MASK_PALETTE) {
        png_destroy_read_struct(&png_ptr, &info_ptr, NULL);
        return 0;
    }

        /* Optionally, read the colormap */
    if (pcmap) {
        bit_depth = png_get_bit_depth(png_ptr, info_ptr);
        png_get_PLTE(png_ptr, info_ptr, &palette, &num_palette);
        *pcmap = pixcmapCreate(bit_depth);  /* spp == 1 */
        for (cindex = 0; cindex < num_palette; cindex++) {
            rval = palette[cindex].red;
            gval = palette[cindex].green;
            bval = palette[cindex].blue;
            pixcmapAddColor(*pcmap, rval, gval, bval);
        }
    }

        /* Optionally, look for transparency.  Note that the colormap
         * has been initialized to fully opaque. */
    if (ptransparency && png_get_valid(png_ptr, info_ptr, PNG_INFO_tRNS)) {
        png_get_tRNS(png_ptr, info_ptr, &trans, &num_trans, NULL);
        if (trans) {
            for (i = 0; i < num_trans; i++) {
                if (trans[i] < 255) {  /* not fully opaque */
                    *ptransparency = 1;
                    if (pcmap) pixcmapSetAlpha(*pcmap, i, trans[i]);
                }
            }
        } else {
            L_ERROR("transparency array not returned\n", procName);
        }
    }

    png_destroy_read_struct(&png_ptr, &info_ptr, NULL);
    rewind(fp);
    return 0;
}