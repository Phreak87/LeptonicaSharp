﻿
size_t
fnbytesInFile(FILE  *fp)
{
l_int64  pos, nbytes;

    PROCNAME("fnbytesInFile");

    if (!fp)
        return ERROR_INT("stream not open", procName, 0);

    pos = ftell(fp);          /* initial position */
    if (pos < 0)
        return ERROR_INT("seek position must be > 0", procName, 0);
    fseek(fp, 0, SEEK_END);   /* EOF */
    nbytes = ftell(fp);
    fseek(fp, pos, SEEK_SET);        /* back to initial position */
    return nbytes;
}