﻿
PIX *
fpixAutoRenderContours(FPIX    *fpix,
                       l_int32  ncontours)
{
l_float32  minval, maxval, incr;

    PROCNAME("fpixAutoRenderContours");

    if (!fpix)
        return (PIX *)ERROR_PTR("fpix not defined", procName, NULL);
    if (ncontours < 2 || ncontours > 500)
        return (PIX *)ERROR_PTR("ncontours < 2 or > 500", procName, NULL);

    fpixGetMin(fpix, &minval, NULL, NULL);
    fpixGetMax(fpix, &maxval, NULL, NULL);
    if (minval == maxval)
        return (PIX *)ERROR_PTR("all values in fpix are equal", procName, NULL);
    incr = (maxval - minval) / ((l_float32)ncontours - 1);
    return fpixRenderContours(fpix, incr, 0.15);
}