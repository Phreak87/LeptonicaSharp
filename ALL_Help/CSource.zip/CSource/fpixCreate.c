﻿
FPIX *
fpixCreate(l_int32  width,
           l_int32  height)
{
l_float32  *data;
l_uint64    npix64;
FPIX       *fpixd;

    PROCNAME("fpixCreate");

    if (width <= 0)
        return (FPIX *)ERROR_PTR("width must be > 0", procName, NULL);
    if (height <= 0)
        return (FPIX *)ERROR_PTR("height must be > 0", procName, NULL);

        /* Avoid overflow in malloc arg, malicious or otherwise */
    npix64 = (l_uint64)width * (l_uint64)height;   /* # of 4-byte pixels */
    if (npix64 >= (1LL << 29)) {
        L_ERROR("requested w = %d, h = %d\n", procName, width, height);
        return (FPIX *)ERROR_PTR("requested bytes >= 2^31", procName, NULL);
    }

    fpixd = (FPIX *)LEPT_CALLOC(1, sizeof(FPIX));
    fpixSetDimensions(fpixd, width, height);
    fpixSetWpl(fpixd, width);  /* 4-byte words */
    fpixd->refcount = 1;

    data = (l_float32 *)LEPT_CALLOC(width * height, sizeof(l_float32));
    if (!data) {
        fpixDestroy(&fpixd);
        return (FPIX *)ERROR_PTR("calloc fail for data", procName, NULL);
    }
    fpixSetData(fpixd, data);
    return fpixd;
}