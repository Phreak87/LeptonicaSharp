﻿
l_ok
fpixGetDimensions(FPIX     *fpix,
                  l_int32  *pw,
                  l_int32  *ph)
{
    PROCNAME("fpixGetDimensions");

    if (!pw && !ph)
        return ERROR_INT("no return val requested", procName, 1);
    if (pw) *pw = 0;
    if (ph) *ph = 0;
    if (!fpix)
        return ERROR_INT("fpix not defined", procName, 1);
    if (pw) *pw = fpix->w;
    if (ph) *ph = fpix->h;
    return 0;
}