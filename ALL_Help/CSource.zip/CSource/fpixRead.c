﻿
FPIX *
fpixRead(const char  *filename)
{
FILE  *fp;
FPIX  *fpix;

    PROCNAME("fpixRead");

    if (!filename)
        return (FPIX *)ERROR_PTR("filename not defined", procName, NULL);

    if ((fp = fopenReadStream(filename)) == NULL)
        return (FPIX *)ERROR_PTR("stream not opened", procName, NULL);
    fpix = fpixReadStream(fp);
    fclose(fp);
    if (!fpix)
        return (FPIX *)ERROR_PTR("fpix not read", procName, NULL);
    return fpix;
}