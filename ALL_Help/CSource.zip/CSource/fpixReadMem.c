﻿
FPIX *
fpixReadMem(const l_uint8  *data,
            size_t          size)
{
FILE  *fp;
FPIX  *fpix;

    PROCNAME("fpixReadMem");

    if (!data)
        return (FPIX *)ERROR_PTR("data not defined", procName, NULL);
    if ((fp = fopenReadFromMemory(data, size)) == NULL)
        return (FPIX *)ERROR_PTR("stream not opened", procName, NULL);

    fpix = fpixReadStream(fp);
    fclose(fp);
    if (!fpix) L_ERROR("fpix not read\n", procName);
    return fpix;
}