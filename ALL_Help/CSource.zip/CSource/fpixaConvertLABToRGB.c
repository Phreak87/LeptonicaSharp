﻿
PIX *
fpixaConvertLABToRGB(FPIXA  *fpixa)
{
l_int32     w, h, wpls, wpld, i, j, rval, gval, bval;
l_float32   flval, faval, fbval;
l_float32  *linel, *linea, *lineb, *datal, *dataa, *datab;
l_uint32   *lined, *datad;
PIX        *pixd;
FPIX       *fpix;

    PROCNAME("fpixaConvertLABToRGB");

    if (!fpixa || fpixaGetCount(fpixa) != 3)
        return (PIX *)ERROR_PTR("fpixa undefined or invalid", procName, NULL);

        /* Convert LAB image */
    if (fpixaGetFPixDimensions(fpixa, 0, &w, &h))
        return (PIX *)ERROR_PTR("fpixa dimensions not found", procName, NULL);
    pixd = pixCreate(w, h, 32);
    wpld = pixGetWpl(pixd);
    datad = pixGetData(pixd);
    datal = fpixaGetData(fpixa, 0);
    dataa = fpixaGetData(fpixa, 1);
    datab = fpixaGetData(fpixa, 2);
    fpix = fpixaGetFPix(fpixa, 0, L_CLONE);
    wpls = fpixGetWpl(fpix);
    fpixDestroy(&fpix);
    for (i = 0; i < h; i++) {
        linel = datal + i * wpls;
        linea = dataa + i * wpls;
        lineb = datab + i * wpls;
        lined = datad + i * wpld;
        for (j = 0; j < w; j++) {
            flval = linel[j];
            faval = linea[j];
            fbval = lineb[j];
            convertLABToRGB(flval, faval, fbval, &rval, &gval, &bval);
            composeRGBPixel(rval, gval, bval, lined + j);
        }
    }

    return pixd;
}