﻿
FPIXA *
fpixaConvertLABToXYZ(FPIXA  *fpixas)
{
l_int32     w, h, wpl, i, j;
l_float32   fxval, fyval, fzval, flval, faval, fbval;
l_float32  *linel, *linea, *lineb, *datal, *dataa, *datab;
l_float32  *linex, *liney, *linez, *datax, *datay, *dataz;
FPIX       *fpix;
FPIXA      *fpixad;

    PROCNAME("fpixaConvertLABToXYZ");

    if (!fpixas || fpixaGetCount(fpixas) != 3)
        return (FPIXA *)ERROR_PTR("fpixas undefined/invalid", procName, NULL);

        /* Convert LAB image */
    if (fpixaGetFPixDimensions(fpixas, 0, &w, &h))
        return (FPIXA *)ERROR_PTR("fpixas sizes not found", procName, NULL);
    fpixad = fpixaCreate(3);
    for (i = 0; i < 3; i++) {
        fpix = fpixCreate(w, h);
        fpixaAddFPix(fpixad, fpix, L_INSERT);
    }
    wpl = fpixGetWpl(fpix);
    datal = fpixaGetData(fpixas, 0);
    dataa = fpixaGetData(fpixas, 1);
    datab = fpixaGetData(fpixas, 2);
    datax = fpixaGetData(fpixad, 0);
    datay = fpixaGetData(fpixad, 1);
    dataz = fpixaGetData(fpixad, 2);

        /* Convert XYZ image */
    for (i = 0; i < h; i++) {
        linel = datal + i * wpl;
        linea = dataa + i * wpl;
        lineb = datab + i * wpl;
        linex = datax + i * wpl;
        liney = datay + i * wpl;
        linez = dataz + i * wpl;
        for (j = 0; j < w; j++) {
            flval = *(linel + j);
            faval = *(linea + j);
            fbval = *(lineb + j);
            convertLABToXYZ(flval, faval, fbval, &fxval, &fyval, &fzval);
            *(linex + j) = fxval;
            *(liney + j) = fyval;
            *(linez + j) = fzval;
        }
    }

    return fpixad;
}