﻿
FPIXA *
fpixaConvertXYZToLAB(FPIXA  *fpixas)
{
l_int32     w, h, wpl, i, j;
l_float32   fxval, fyval, fzval, flval, faval, fbval;
l_float32  *linex, *liney, *linez, *datax, *datay, *dataz;
l_float32  *linel, *linea, *lineb, *datal, *dataa, *datab;
FPIX       *fpix;
FPIXA      *fpixad;

    PROCNAME("fpixaConvertXYZToLAB");

    if (!fpixas || fpixaGetCount(fpixas) != 3)
        return (FPIXA *)ERROR_PTR("fpixas undefined/invalid", procName, NULL);

        /* Convert XYZ image */
    if (fpixaGetFPixDimensions(fpixas, 0, &w, &h))
        return (FPIXA *)ERROR_PTR("fpixas sizes not found", procName, NULL);
    fpixad = fpixaCreate(3);
    for (i = 0; i < 3; i++) {
        fpix = fpixCreate(w, h);
        fpixaAddFPix(fpixad, fpix, L_INSERT);
    }
    wpl = fpixGetWpl(fpix);
    datax = fpixaGetData(fpixas, 0);
    datay = fpixaGetData(fpixas, 1);
    dataz = fpixaGetData(fpixas, 2);
    datal = fpixaGetData(fpixad, 0);
    dataa = fpixaGetData(fpixad, 1);
    datab = fpixaGetData(fpixad, 2);

        /* Convert XYZ image */
    for (i = 0; i < h; i++) {
        linex = datax + i * wpl;
        liney = datay + i * wpl;
        linez = dataz + i * wpl;
        linel = datal + i * wpl;
        linea = dataa + i * wpl;
        lineb = datab + i * wpl;
        for (j = 0; j < w; j++) {
            fxval = *(linex + j);
            fyval = *(liney + j);
            fzval = *(linez + j);
            convertXYZToLAB(fxval, fyval, fzval, &flval, &faval, &fbval);
            *(linel + j) = flval;
            *(linea + j) = faval;
            *(lineb + j) = fbval;
        }
    }

    return fpixad;
}