﻿
FPIXA *
fpixaCreate(l_int32  n)
{
FPIXA  *fpixa;

    PROCNAME("fpixaCreate");

    if (n <= 0)
        n = INITIAL_PTR_ARRAYSIZE;

    if ((fpixa = (FPIXA *)LEPT_CALLOC(1, sizeof(FPIXA))) == NULL)
        return (FPIXA *)ERROR_PTR("fpixa not made", procName, NULL);
    fpixa->n = 0;
    fpixa->nalloc = n;
    fpixa->refcount = 1;

    if ((fpixa->fpix = (FPIX **)LEPT_CALLOC(n, sizeof(FPIX *))) == NULL) {
        fpixaDestroy(&fpixa);
        return (FPIXA *)ERROR_PTR("fpixa ptrs not made", procName, NULL);
    }

    return fpixa;
}