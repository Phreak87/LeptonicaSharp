﻿
l_float32 *
fpixaGetData(FPIXA      *fpixa,
             l_int32     index)
{
l_int32     n;
l_float32  *data;
FPIX       *fpix;

    PROCNAME("fpixaGetData");

    if (!fpixa)
        return (l_float32 *)ERROR_PTR("fpixa not defined", procName, NULL);
    n = fpixaGetCount(fpixa);
    if (index < 0 || index >= n)
        return (l_float32 *)ERROR_PTR("invalid index", procName, NULL);

    fpix = fpixaGetFPix(fpixa, index, L_CLONE);
    data = fpixGetData(fpix);
    fpixDestroy(&fpix);
    return data;
}