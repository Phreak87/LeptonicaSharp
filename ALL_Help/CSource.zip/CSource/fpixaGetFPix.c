﻿
FPIX *
fpixaGetFPix(FPIXA   *fpixa,
             l_int32  index,
             l_int32  accesstype)
{
    PROCNAME("fpixaGetFPix");

    if (!fpixa)
        return (FPIX *)ERROR_PTR("fpixa not defined", procName, NULL);
    if (index < 0 || index >= fpixa->n)
        return (FPIX *)ERROR_PTR("index not valid", procName, NULL);

    if (accesstype == L_COPY)
        return fpixCopy(NULL, fpixa->fpix[index]);
    else if (accesstype == L_CLONE)
        return fpixClone(fpixa->fpix[index]);
    else
        return (FPIX *)ERROR_PTR("invalid accesstype", procName, NULL);
}