﻿
l_ok
fpixaGetFPixDimensions(FPIXA    *fpixa,
                       l_int32   index,
                       l_int32  *pw,
                       l_int32  *ph)
{
FPIX  *fpix;

    PROCNAME("fpixaGetFPixDimensions");

    if (!pw && !ph)
        return ERROR_INT("no return val requested", procName, 1);
    if (pw) *pw = 0;
    if (ph) *ph = 0;
    if (!fpixa)
        return ERROR_INT("fpixa not defined", procName, 1);
    if (index < 0 || index >= fpixa->n)
        return ERROR_INT("index not valid", procName, 1);

    if ((fpix = fpixaGetFPix(fpixa, index, L_CLONE)) == NULL)
        return ERROR_INT("fpix not found!", procName, 1);
    fpixGetDimensions(fpix, pw, ph);
    fpixDestroy(&fpix);
    return 0;
}