﻿
l_int32
gaussjordan(l_float32  **a,
            l_float32   *b,
            l_int32      n)
{
l_int32    i, icol, irow, j, k, col, row, success;
l_int32   *indexc, *indexr, *ipiv;
l_float32  maxval, val, pivinv, temp;

    PROCNAME("gaussjordan");

    if (!a)
        return ERROR_INT("a not defined", procName, 1);
    if (!b)
        return ERROR_INT("b not defined", procName, 1);

    success = TRUE;
    indexc = (l_int32 *)LEPT_CALLOC(n, sizeof(l_int32));
    indexr = (l_int32 *)LEPT_CALLOC(n, sizeof(l_int32));
    ipiv = (l_int32 *)LEPT_CALLOC(n, sizeof(l_int32));
    if (!indexc || !indexr || !ipiv) {
        L_ERROR("array not made\n", procName);
        success = FALSE;
        goto cleanup_arrays;
    }

    icol = irow = 0;  /* silence static checker */
    for (i = 0; i < n; i++) {
        maxval = 0.0;
        for (j = 0; j < n; j++) {
            if (ipiv[j] != 1) {
                for (k = 0; k < n; k++) {
                    if (ipiv[k] == 0) {
                        if (fabs(a[j][k]) >= maxval) {
                            maxval = fabs(a[j][k]);
                            irow = j;
                            icol = k;
                        }
                    } else if (ipiv[k] > 1) {
                        L_ERROR("singular matrix\n", procName);
                        success = FALSE;
                        goto cleanup_arrays;
                    }
                }
            }
        }
        ++(ipiv[icol]);

        if (irow != icol) {
            for (col = 0; col < n; col++)
                SWAP(a[irow][col], a[icol][col]);
            SWAP(b[irow], b[icol]);
        }

        indexr[i] = irow;
        indexc[i] = icol;
        if (a[icol][icol] == 0.0) {
            L_ERROR("singular matrix\n", procName);
            success = FALSE;
            goto cleanup_arrays;
        }
        pivinv = 1.0 / a[icol][icol];
        a[icol][icol] = 1.0;
        for (col = 0; col < n; col++)
            a[icol][col] *= pivinv;
        b[icol] *= pivinv;

        for (row = 0; row < n; row++) {
            if (row != icol) {
                val = a[row][icol];
                a[row][icol] = 0.0;
                for (col = 0; col < n; col++)
                    a[row][col] -= a[icol][col] * val;
                b[row] -= b[icol] * val;
            }
        }
    }

    for (col = n - 1; col >= 0; col--) {
        if (indexr[col] != indexc[col]) {
            for (k = 0; k < n; k++)
                SWAP(a[k][indexr[col]], a[k][indexc[col]]);
        }
    }

cleanup_arrays:
    LEPT_FREE(indexr);
    LEPT_FREE(indexc);
    LEPT_FREE(ipiv);
    return (success) ? 0 : 1;
}