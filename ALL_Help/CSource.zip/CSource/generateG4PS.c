﻿
char *
generateG4PS(const char   *filein,
             L_COMP_DATA  *cid,
             l_float32     xpt,
             l_float32     ypt,
             l_float32     wpt,
             l_float32     hpt,
             l_int32       maskflag,
             l_int32       pageno,
             l_int32       endpage)
{
l_int32  w, h;
char    *outstr;
char     bigbuf[L_BUF_SIZE];
SARRAY  *sa;

    PROCNAME("generateG4PS");

    if (!cid)
        return (char *)ERROR_PTR("g4 data not defined", procName, NULL);
    w = cid->w;
    h = cid->h;

    if ((sa = sarrayCreate(50)) == NULL)
        return (char *)ERROR_PTR("sa not made", procName, NULL);

    sarrayAddString(sa, "%!PS-Adobe-3.0", L_COPY);
    sarrayAddString(sa, "%%Creator: leptonica", L_COPY);
    if (filein)
        snprintf(bigbuf, sizeof(bigbuf), "%%%%Title: %s", filein);
    else
        snprintf(bigbuf, sizeof(bigbuf), "%%%%Title: G4 compressed PS");
    sarrayAddString(sa, bigbuf, L_COPY);
    sarrayAddString(sa, "%%DocumentData: Clean7Bit", L_COPY);

    if (var_PS_WRITE_BOUNDING_BOX == 1) {
        snprintf(bigbuf, sizeof(bigbuf),
            "%%%%BoundingBox: %7.2f %7.2f %7.2f %7.2f",
                    xpt, ypt, xpt + wpt, ypt + hpt);
        sarrayAddString(sa, bigbuf, L_COPY);
    }

    sarrayAddString(sa, "%%LanguageLevel: 2", L_COPY);
    sarrayAddString(sa, "%%EndComments", L_COPY);
    snprintf(bigbuf, sizeof(bigbuf), "%%%%Page: %d %d", pageno, pageno);
    sarrayAddString(sa, bigbuf, L_COPY);

    sarrayAddString(sa, "save", L_COPY);
    sarrayAddString(sa, "100 dict begin", L_COPY);

    snprintf(bigbuf, sizeof(bigbuf),
        "%7.2f %7.2f translate         %%set image origin in pts", xpt, ypt);
    sarrayAddString(sa, bigbuf, L_COPY);

    snprintf(bigbuf, sizeof(bigbuf),
        "%7.2f %7.2f scale             %%set image size in pts", wpt, hpt);
    sarrayAddString(sa, bigbuf, L_COPY);

    sarrayAddString(sa, "/DeviceGray setcolorspace", L_COPY);

    sarrayAddString(sa, "{", L_COPY);
    sarrayAddString(sa,
          "  /RawData currentfile /ASCII85Decode filter def", L_COPY);
    sarrayAddString(sa, "  << ", L_COPY);
    sarrayAddString(sa, "    /ImageType 1", L_COPY);
    snprintf(bigbuf, sizeof(bigbuf), "    /Width %d", w);
    sarrayAddString(sa, bigbuf, L_COPY);
    snprintf(bigbuf, sizeof(bigbuf), "    /Height %d", h);
    sarrayAddString(sa, bigbuf, L_COPY);
    snprintf(bigbuf, sizeof(bigbuf),
             "    /ImageMatrix [ %d 0 0 %d 0 %d ]", w, -h, h);
    sarrayAddString(sa, bigbuf, L_COPY);
    sarrayAddString(sa, "    /BitsPerComponent 1", L_COPY);
    sarrayAddString(sa, "    /Interpolate true", L_COPY);
    if (cid->minisblack)
        sarrayAddString(sa, "    /Decode [1 0]", L_COPY);
    else  /* miniswhite; typical for 1 bpp */
        sarrayAddString(sa, "    /Decode [0 1]", L_COPY);
    sarrayAddString(sa, "    /DataSource RawData", L_COPY);
    sarrayAddString(sa, "        <<", L_COPY);
    sarrayAddString(sa, "          /K -1", L_COPY);
    snprintf(bigbuf, sizeof(bigbuf), "          /Columns %d", w);
    sarrayAddString(sa, bigbuf, L_COPY);
    snprintf(bigbuf, sizeof(bigbuf), "          /Rows %d", h);
    sarrayAddString(sa, bigbuf, L_COPY);
    sarrayAddString(sa, "        >> /CCITTFaxDecode filter", L_COPY);
    if (maskflag == TRUE)  /* just paint through the fg */
        sarrayAddString(sa, "  >> imagemask", L_COPY);
    else  /* Paint full image */
        sarrayAddString(sa, "  >> image", L_COPY);
    sarrayAddString(sa, "  RawData flushfile", L_COPY);
    if (endpage == TRUE)
        sarrayAddString(sa, "  showpage", L_COPY);
    sarrayAddString(sa, "}", L_COPY);

    sarrayAddString(sa, "%%BeginData:", L_COPY);
    sarrayAddString(sa, "exec", L_COPY);

        /* Insert the ascii85 ccittg4 data; this is now owned by sa */
    sarrayAddString(sa, cid->data85, L_INSERT);

        /* Concat the trailing data */
    sarrayAddString(sa, "%%EndData", L_COPY);
    sarrayAddString(sa, "end", L_COPY);
    sarrayAddString(sa, "restore", L_COPY);

    outstr = sarrayToString(sa, 1);
    sarrayDestroy(&sa);
    cid->data85 = NULL;  /* it has been transferred and destroyed */
    return outstr;
}