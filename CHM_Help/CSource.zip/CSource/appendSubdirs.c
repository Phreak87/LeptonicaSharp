﻿

char *
appendSubdirs(const char  *basedir,
              const char  *subdirs)
{
char   *newdir;
size_t  len1, len2, len3, len4;

    PROCNAME("appendSubdirs");

    if (!basedir || !subdirs)
        return (char *)ERROR_PTR("basedir and subdirs not both defined",
                                 procName, NULL);

    len1 = strlen(basedir);
    len2 = strlen(subdirs);
    len3 = len1 + len2 + 6;
    if ((newdir = (char *)LEPT_CALLOC(len3 + 1, 1)) == NULL)
        return (char *)ERROR_PTR("newdir not made", procName, NULL);
    strncat(newdir, basedir, len3);  /* add basedir */
    if (newdir[len1 - 1] != '/')  /* add '/' if necessary */
        newdir[len1] = '/';
    if (subdirs[0] == '/')  /* add subdirs, stripping leading '/' */
        strncat(newdir, subdirs + 1, len3);
    else
        strncat(newdir, subdirs, len3);
    len4 = strlen(newdir);
    if (newdir[len4 - 1] == '/')  /* strip trailing '/' */
        newdir[len4 - 1] = '\0';

    return newdir;
}