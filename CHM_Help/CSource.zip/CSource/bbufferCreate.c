﻿
static const l_int32  INITIAL_BUFFER_ARRAYSIZE = 1024

L_BBUFFER *
bbufferCreate(const l_uint8  *indata,
              l_int32         nalloc)
{
L_BBUFFER  *bb;

    PROCNAME("bbufferCreate");

    if (nalloc <= 0)
        nalloc = INITIAL_BUFFER_ARRAYSIZE;

    if ((bb = (L_BBUFFER *)LEPT_CALLOC(1, sizeof(L_BBUFFER))) == NULL)
        return (L_BBUFFER *)ERROR_PTR("bb not made", procName, NULL);
    if ((bb->array = (l_uint8 *)LEPT_CALLOC(nalloc, sizeof(l_uint8))) == NULL) {
        LEPT_FREE(bb);
        return (L_BBUFFER *)ERROR_PTR("byte array not made", procName, NULL);
    }
    bb->nalloc = nalloc;
    bb->nwritten = 0;

    if (indata) {
        memcpy(bb->array, indata, nalloc);
        bb->n = nalloc;
    } else {
        bb->n = 0;
    }

    return bb;
}