﻿

l_ok
boxGetSideLocations(BOX      *box,
                    l_int32  *pl,
                    l_int32  *pr,
                    l_int32  *pt,
                    l_int32  *pb)
{
l_int32  x, y, w, h;

    PROCNAME("boxGetSideLocations");

    if (pl) *pl = 0;
    if (pr) *pr = 0;
    if (pt) *pt = 0;
    if (pb) *pb = 0;
    if (!box)
        return ERROR_INT("box not defined", procName, 1);

    boxGetGeometry(box, &x, &y, &w, &h);
    if (pl) *pl = x;
    if (pr) *pr = x + w - 1;
    if (pt) *pt = y;
    if (pb) *pb = y + h - 1;
    return 0;
}