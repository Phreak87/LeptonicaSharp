﻿

BOXA *
boxaAdjustSides(BOXA    *boxas,
                l_int32  delleft,
                l_int32  delright,
                l_int32  deltop,
                l_int32  delbot)
{
l_int32  n, i, x, y;
BOX     *box1, *box2;
BOXA    *boxad;

    PROCNAME("boxaAdjustSides");

    if (!boxas)
        return (BOXA *)ERROR_PTR("boxas not defined", procName, NULL);

    n = boxaGetCount(boxas);
    boxad = boxaCreate(n);
    for (i = 0; i < n; i++) {
        box1 = boxaGetBox(boxas, i, L_COPY);
        box2 = boxAdjustSides(NULL, box1, delleft, delright, deltop, delbot);
        if (!box2) {
            boxGetGeometry(box1, &x, &y, NULL, NULL);
            box2 = boxCreate(x, y, 1, 1);
        }
        boxaAddBox(boxad, box2, L_INSERT);
        boxDestroy(&box1);
    }

    return boxad;
}