﻿

l_ok
boxaExtractAsNuma(BOXA    *boxa,
                  NUMA   **pnal,
                  NUMA   **pnat,
                  NUMA   **pnar,
                  NUMA   **pnab,
                  NUMA   **pnaw,
                  NUMA   **pnah,
                  l_int32  keepinvalid)
{
l_int32  i, n, left, top, right, bot, w, h;

    PROCNAME("boxaExtractAsNuma");

    if (!pnal && !pnat && !pnar && !pnab && !pnaw && !pnah)
        return ERROR_INT("no output requested", procName, 1);
    if (pnal) *pnal = NULL;
    if (pnat) *pnat = NULL;
    if (pnar) *pnar = NULL;
    if (pnab) *pnab = NULL;
    if (pnaw) *pnaw = NULL;
    if (pnah) *pnah = NULL;
    if (!boxa)
        return ERROR_INT("boxa not defined", procName, 1);
    if (!keepinvalid && boxaGetValidCount(boxa) == 0)
        return ERROR_INT("no valid boxes", procName, 1);

    n = boxaGetCount(boxa);
    if (pnal) *pnal = numaCreate(n);
    if (pnat) *pnat = numaCreate(n);
    if (pnar) *pnar = numaCreate(n);
    if (pnab) *pnab = numaCreate(n);
    if (pnaw) *pnaw = numaCreate(n);
    if (pnah) *pnah = numaCreate(n);
    for (i = 0; i < n; i++) {
        boxaGetBoxGeometry(boxa, i, &left, &top, &w, &h);
        if (!keepinvalid && (w <= 0 || h <= 0))
            continue;
        right = left + w - 1;
        bot = top + h - 1;
        if (pnal) numaAddNumber(*pnal, left);
        if (pnat) numaAddNumber(*pnat, top);
        if (pnar) numaAddNumber(*pnar, right);
        if (pnab) numaAddNumber(*pnab, bot);
        if (pnaw) numaAddNumber(*pnaw, w);
        if (pnah) numaAddNumber(*pnah, h);
    }

    return 0;
}