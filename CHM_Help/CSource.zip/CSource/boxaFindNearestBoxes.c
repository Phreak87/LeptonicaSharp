﻿

l_ok
boxaFindNearestBoxes(BOXA     *boxa,
                     l_int32   dist_select,
                     l_int32   range,
                     NUMAA   **pnaaindex,
                     NUMAA   **pnaadist)
{
l_int32  i, n, index, dist;
NUMA    *nai, *nad;
NUMAA   *naai, *naad;

    PROCNAME("boxaFindNearestBoxes");

    if (pnaaindex) *pnaaindex = NULL;
    if (pnaadist) *pnaadist = NULL;
    if (!pnaaindex)
        return ERROR_INT("&naaindex not defined", procName, 1);
    if (!pnaadist)
        return ERROR_INT("&naadist not defined", procName, 1);
    if (!boxa)
        return ERROR_INT("boxa not defined", procName, 1);

    n = boxaGetCount(boxa);
    naai = numaaCreate(n);
    naad = numaaCreate(n);
    *pnaaindex = naai;
    *pnaadist = naad;
    for (i = 0; i < n; i++) {
        nai = numaCreate(4);
        nad = numaCreate(4);
        boxaGetNearestByDirection(boxa, i, L_FROM_LEFT, dist_select,
                                  range, &index, &dist);
        numaAddNumber(nai, index);
        numaAddNumber(nad, dist);
        boxaGetNearestByDirection(boxa, i, L_FROM_RIGHT, dist_select,
                                  range, &index, &dist);
        numaAddNumber(nai, index);
        numaAddNumber(nad, dist);
        boxaGetNearestByDirection(boxa, i, L_FROM_TOP, dist_select,
                                  range, &index, &dist);
        numaAddNumber(nai, index);
        numaAddNumber(nad, dist);
        boxaGetNearestByDirection(boxa, i, L_FROM_BOT, dist_select,
                                  range, &index, &dist);
        numaAddNumber(nai, index);
        numaAddNumber(nad, dist);
        numaaAddNuma(naai, nai, L_INSERT);
        numaaAddNuma(naad, nad, L_INSERT);
    }
    return 0;
}