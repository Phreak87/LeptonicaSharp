﻿

l_ok
boxaGetMedianVals(BOXA     *boxa,
                  l_int32  *px,
                  l_int32  *py,
                  l_int32  *pw,
                  l_int32  *ph)
{
    PROCNAME("boxaGetMedianVals");

    if (!boxa)
        return ERROR_INT("boxa not defined", procName, 1);
    if (boxaGetValidCount(boxa) == 0)
        return ERROR_INT("no valid boxes in boxa", procName, 1);

    return boxaGetRankVals(boxa, 0.5, px, py, pw, ph);
}