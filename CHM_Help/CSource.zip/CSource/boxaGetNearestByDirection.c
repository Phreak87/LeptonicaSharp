﻿

l_ok
boxaGetNearestByDirection(BOXA     *boxa,
                          l_int32   i,
                          l_int32   dir,
                          l_int32   dist_select,
                          l_int32   range,
                          l_int32  *pindex,
                          l_int32  *pdist)
{
l_int32  j, jmin, jmax, n, mindist, dist, index;
l_int32  x, y, w, h, bx, by, bw, bh;

    PROCNAME("boxaGetNearestByDirection");

    if (pindex) *pindex = -1;
    if (pdist) *pdist = 100000;
    if (!pindex)
        return ERROR_INT("&index not defined", procName, 1);
    if (!pdist)
        return ERROR_INT("&dist not defined", procName, 1);
    if (!boxa)
        return ERROR_INT("boxa not defined", procName, 1);
    if (dir != L_FROM_LEFT && dir != L_FROM_RIGHT &&
        dir != L_FROM_TOP && dir != L_FROM_BOT)
        return ERROR_INT("invalid dir", procName, 1);
    if (dist_select != L_NON_NEGATIVE && dist_select != L_ALL)
        return ERROR_INT("invalid dist_select", procName, 1);
    n = boxaGetCount(boxa);
    if (i < 0 || i >= n)
        return ERROR_INT("invalid box index", procName, 1);

    jmin = (range <= 0) ? 0 : L_MAX(0, i - range);
    jmax = (range <= 0) ? n - 1 : L_MIN(n -1, i + range);
    boxaGetBoxGeometry(boxa, i, &x, &y, &w, &h);
    mindist = 100000;
    index = -1;
    if (dir == L_FROM_LEFT || dir == L_FROM_RIGHT) {
        for (j = jmin; j <= jmax; j++) {
            if (j == i) continue;
            boxaGetBoxGeometry(boxa, j, &bx, &by, &bw, &bh);
            if ((bx >= x && dir == L_FROM_LEFT) ||  /* not to the left */
                (x >= bx && dir == L_FROM_RIGHT))   /* not to the right */
                continue;
            if (boxHasOverlapInXorY(y, h, by, bh) == 1) {
                dist = boxGetDistanceInXorY(x, w, bx, bw);
                if (dist_select == L_NON_NEGATIVE && dist < 0) continue;
                if (dist < mindist) {
                    mindist = dist;
                    index = j;
                }
            }
        }
    } else if (dir == L_FROM_TOP || dir == L_FROM_BOT) {
        for (j = jmin; j <= jmax; j++) {
            if (j == i) continue;
            boxaGetBoxGeometry(boxa, j, &bx, &by, &bw, &bh);
            if ((by >= y && dir == L_FROM_TOP) ||  /* not above */
                (y >= by && dir == L_FROM_BOT))   /* not below */
                continue;
            if (boxHasOverlapInXorY(x, w, bx, bw) == 1) {
                dist = boxGetDistanceInXorY(y, h, by, bh);
                if (dist_select == L_NON_NEGATIVE && dist < 0) continue;
                if (dist < mindist) {
                    mindist = dist;
                    index = j;
                }
            }
        }
    }
    *pindex = index;
    *pdist = mindist;
    return 0;
}