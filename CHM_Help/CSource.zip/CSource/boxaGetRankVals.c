﻿

l_ok
boxaGetRankVals(BOXA      *boxa,
                l_float32  fract,
                l_int32   *px,
                l_int32   *py,
                l_int32   *pw,
                l_int32   *ph)
{
l_float32  xval, yval, wval, hval;
NUMA      *nax, *nay, *naw, *nah;

    PROCNAME("boxaGetRankVals");

    if (px) *px = 0;
    if (py) *py = 0;
    if (pw) *pw = 0;
    if (ph) *ph = 0;
    if (!boxa)
        return ERROR_INT("boxa not defined", procName, 1);
    if (fract < 0.0 || fract > 1.0)
        return ERROR_INT("fract not in [0.0 ... 1.0]", procName, 1);
    if (boxaGetValidCount(boxa) == 0)
        return ERROR_INT("no valid boxes in boxa", procName, 1);

        /* Use only the valid boxes */
    boxaExtractAsNuma(boxa, &nax, &nay, NULL, NULL, &naw, &nah, 0);

    if (px) {
        numaGetRankValue(nax, 1.0 - fract, NULL, 1, &xval);
        *px = (l_int32)xval;
    }
    if (py) {
        numaGetRankValue(nay, 1.0 - fract, NULL, 1, &yval);
        *py = (l_int32)yval;
    }
    if (pw) {
        numaGetRankValue(naw, fract, NULL, 1, &wval);
        *pw = (l_int32)wval;
    }
    if (ph) {
        numaGetRankValue(nah, fract, NULL, 1, &hval);
        *ph = (l_int32)hval;
    }
    numaDestroy(&nax);
    numaDestroy(&nay);
    numaDestroy(&naw);
    numaDestroy(&nah);
    return 0;
}