﻿

BOXAA *
boxaSort2d(BOXA    *boxas,
           NUMAA  **pnaad,
           l_int32  delta1,
           l_int32  delta2,
           l_int32  minh1)
{
l_int32  i, index, h, nt, ne, n, m, ival;
BOX     *box;
BOXA    *boxa, *boxae, *boxan, *boxa1, *boxa2, *boxa3, *boxav, *boxavs;
BOXAA   *baa, *baa1, *baad;
NUMA    *naindex, *nae, *nan, *nah, *nav, *na1, *na2, *nad, *namap;
NUMAA   *naa, *naa1, *naad;

    PROCNAME("boxaSort2d");

    if (pnaad) *pnaad = NULL;
    if (!boxas)
        return (BOXAA *)ERROR_PTR("boxas not defined", procName, NULL);
    if (boxaGetCount(boxas) == 0)
        return (BOXAA *)ERROR_PTR("boxas is empty", procName, NULL);

        /* Sort from left to right */
    if ((boxa = boxaSort(boxas, L_SORT_BY_X, L_SORT_INCREASING, &naindex))
                    == NULL)
        return (BOXAA *)ERROR_PTR("boxa not made", procName, NULL);

        /* First pass: assign taller boxes to boxa by row */
    nt = boxaGetCount(boxa);
    baa = boxaaCreate(0);
    naa = numaaCreate(0);
    boxae = boxaCreate(0);  /* save small height boxes here */
    nae = numaCreate(0);  /* keep track of small height boxes */
    for (i = 0; i < nt; i++) {
        box = boxaGetBox(boxa, i, L_CLONE);
        boxGetGeometry(box, NULL, NULL, NULL, &h);
        if (h < minh1) {  /* save for 2nd pass */
            boxaAddBox(boxae, box, L_INSERT);
            numaAddNumber(nae, i);
        } else {
            n = boxaaGetCount(baa);
            boxaaAlignBox(baa, box, delta1, &index);
            if (index < n) {  /* append to an existing boxa */
                boxaaAddBox(baa, index, box, L_INSERT);
            } else {  /* doesn't align, need new boxa */
                boxan = boxaCreate(0);
                boxaAddBox(boxan, box, L_INSERT);
                boxaaAddBoxa(baa, boxan, L_INSERT);
                nan = numaCreate(0);
                numaaAddNuma(naa, nan, L_INSERT);
            }
            numaGetIValue(naindex, i, &ival);
            numaaAddNumber(naa, index, ival);
        }
    }
    boxaDestroy(&boxa);
    numaDestroy(&naindex);

        /* Second pass: feed in small height boxes */
    ne = boxaGetCount(boxae);
    for (i = 0; i < ne; i++) {
        box = boxaGetBox(boxae, i, L_CLONE);
        n = boxaaGetCount(baa);
        boxaaAlignBox(baa, box, delta2, &index);
        if (index < n) {  /* append to an existing boxa */
            boxaaAddBox(baa, index, box, L_INSERT);
        } else {  /* doesn't align, need new boxa */
            boxan = boxaCreate(0);
            boxaAddBox(boxan, box, L_INSERT);
            boxaaAddBoxa(baa, boxan, L_INSERT);
            nan = numaCreate(0);
            numaaAddNuma(naa, nan, L_INSERT);
        }
        numaGetIValue(nae, i, &ival);  /* location in original boxas */
        numaaAddNumber(naa, index, ival);
    }

        /* Third pass: merge some boxa whose extent is overlapping.
         * Think of these boxa as text lines, where the bounding boxes
         * of the text lines can overlap, but likely won't have
         * a huge overlap.
         * First do a greedy find of pairs of overlapping boxa, where
         * the two boxa overlap by at least 50% of the smaller, and
         * the smaller is not more than half the area of the larger.
         * For such pairs, call the larger one the primary boxa.  The
         * boxes in the smaller one are appended to those in the primary
         * in pass 3a, and the primaries are extracted in pass 3b.
         * In this way, all boxes in the original baa are saved. */
    n = boxaaGetCount(baa);
    boxaaGetExtent(baa, NULL, NULL, NULL, &boxa3);
    boxa1 = boxaHandleOverlaps(boxa3, L_REMOVE_SMALL, 1000, 0.5, 0.5, &namap);
    boxaDestroy(&boxa1);
    boxaDestroy(&boxa3);
    for (i = 0; i < n; i++) {  /* Pass 3a: join selected copies of boxa */
        numaGetIValue(namap, i, &ival);
        if (ival >= 0) {  /* join current to primary boxa[ival] */
            boxa1 = boxaaGetBoxa(baa, i, L_COPY);
            boxa2 = boxaaGetBoxa(baa, ival, L_CLONE);
            boxaJoin(boxa2, boxa1, 0, -1);
            boxaDestroy(&boxa2);
            boxaDestroy(&boxa1);
            na1 = numaaGetNuma(naa, i, L_COPY);
            na2 = numaaGetNuma(naa, ival, L_CLONE);
            numaJoin(na2, na1, 0, -1);
            numaDestroy(&na1);
            numaDestroy(&na2);
        }
    }
    baa1 = boxaaCreate(n);
    naa1 = numaaCreate(n);
    for (i = 0; i < n; i++) {  /* Pass 3b: save primary boxa */
        numaGetIValue(namap, i, &ival);
        if (ival == -1) {
            boxa1 = boxaaGetBoxa(baa, i, L_CLONE);
            boxaaAddBoxa(baa1, boxa1, L_INSERT);
            na1 = numaaGetNuma(naa, i, L_CLONE);
            numaaAddNuma(naa1, na1, L_INSERT);
        }
    }
    numaDestroy(&namap);
    boxaaDestroy(&baa);
    baa = baa1;
    numaaDestroy(&naa);
    naa = naa1;

        /* Sort the boxes in each boxa horizontally */
    m = boxaaGetCount(baa);
    for (i = 0; i < m; i++) {
        boxa1 = boxaaGetBoxa(baa, i, L_CLONE);
        boxa2 = boxaSort(boxa1, L_SORT_BY_X, L_SORT_INCREASING, &nah);
        boxaaReplaceBoxa(baa, i, boxa2);
        na1 = numaaGetNuma(naa, i, L_CLONE);
        na2 = numaSortByIndex(na1, nah);
        numaaReplaceNuma(naa, i, na2);
        boxaDestroy(&boxa1);
        numaDestroy(&na1);
        numaDestroy(&nah);
    }

        /* Sort the boxa vertically within boxaa, using the first box
         * in each boxa. */
    m = boxaaGetCount(baa);
    boxav = boxaCreate(m);  /* holds first box in each boxa in baa */
    naad = numaaCreate(m);
    if (pnaad)
        *pnaad = naad;
    baad = boxaaCreate(m);
    for (i = 0; i < m; i++) {
        boxa1 = boxaaGetBoxa(baa, i, L_CLONE);
        box = boxaGetBox(boxa1, 0, L_CLONE);
        boxaAddBox(boxav, box, L_INSERT);
        boxaDestroy(&boxa1);
    }
    boxavs = boxaSort(boxav, L_SORT_BY_Y, L_SORT_INCREASING, &nav);
    for (i = 0; i < m; i++) {
        numaGetIValue(nav, i, &index);
        boxa = boxaaGetBoxa(baa, index, L_CLONE);
        boxaaAddBoxa(baad, boxa, L_INSERT);
        nad = numaaGetNuma(naa, index, L_CLONE);
        numaaAddNuma(naad, nad, L_INSERT);
    }


/*    fprintf(stderr, "box count = %d, numaa count = %d\n", nt,
            numaaGetNumberCount(naad)); */

    boxaaDestroy(&baa);
    boxaDestroy(&boxav);
    boxaDestroy(&boxavs);
    boxaDestroy(&boxae);
    numaDestroy(&nav);
    numaDestroy(&nae);
    numaaDestroy(&naa);
    if (!pnaad)
        numaaDestroy(&naad);

    return baad;
}