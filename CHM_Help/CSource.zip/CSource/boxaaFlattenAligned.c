﻿

BOXA *
boxaaFlattenAligned(BOXAA   *baa,
                    l_int32  num,
                    BOX     *fillerbox,
                    l_int32  copyflag)
{
l_int32  i, j, m, n, mval, nshort;
BOXA    *boxat, *boxad;
BOX     *box;

    PROCNAME("boxaaFlattenAligned");

    if (!baa)
        return (BOXA *)ERROR_PTR("baa not defined", procName, NULL);
    if (copyflag != L_COPY && copyflag != L_CLONE)
        return (BOXA *)ERROR_PTR("invalid copyflag", procName, NULL);

    n = boxaaGetCount(baa);
    boxad = boxaCreate(n);
    for (i = 0; i < n; i++) {
        boxat = boxaaGetBoxa(baa, i, L_CLONE);
        m = boxaGetCount(boxat);
        mval = L_MIN(m, num);
        nshort = num - mval;
        for (j = 0; j < mval; j++) {  /* take the first %num if possible */
            box = boxaGetBox(boxat, j, copyflag);
            boxaAddBox(boxad, box, L_INSERT);
        }
        for (j = 0; j < nshort; j++) {  /* add fillers if necessary */
            if (fillerbox) {
                boxaAddBox(boxad, fillerbox, L_COPY);
            } else {
                box = boxCreate(0, 0, 0, 0);  /* invalid placeholder box */
                boxaAddBox(boxad, box, L_INSERT);
            }
        }
        boxaDestroy(&boxat);
    }

    return boxad;
}