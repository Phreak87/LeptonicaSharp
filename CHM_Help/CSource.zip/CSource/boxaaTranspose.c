﻿

BOXAA *
boxaaTranspose(BOXAA  *baas)
{
l_int32   i, j, ny, nb, nbox;
BOX      *box;
BOXA     *boxa;
BOXAA    *baad;

    PROCNAME("boxaaTranspose");

    if (!baas)
        return (BOXAA *)ERROR_PTR("baas not defined", procName, NULL);
    if ((ny = boxaaGetCount(baas)) == 0)
        return (BOXAA *)ERROR_PTR("baas empty", procName, NULL);

        /* Make sure that each boxa in baas has the same number of boxes */
    for (i = 0; i < ny; i++) {
        if ((boxa = boxaaGetBoxa(baas, i, L_CLONE)) == NULL)
            return (BOXAA *)ERROR_PTR("baas is missing a boxa", procName, NULL);
        nb = boxaGetCount(boxa);
        boxaDestroy(&boxa);
        if (i == 0)
            nbox = nb;
        else if (nb != nbox)
            return (BOXAA *)ERROR_PTR("boxa are not all the same size",
                                      procName, NULL);
    }

        /* baad[i][j] = baas[j][i] */
    baad = boxaaCreate(nbox);
    for (i = 0; i < nbox; i++) {
        boxa = boxaCreate(ny);
        for (j = 0; j < ny; j++) {
            box = boxaaGetBox(baas, j, i, L_COPY);
            boxaAddBox(boxa, box, L_INSERT);
        }
        boxaaAddBoxa(baad, boxa, L_INSERT);
    }
    return baad;
}