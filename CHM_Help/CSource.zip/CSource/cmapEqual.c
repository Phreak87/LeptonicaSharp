﻿

l_ok
cmapEqual(PIXCMAP  *cmap1,
          PIXCMAP  *cmap2,
          l_int32   ncomps,
          l_int32  *psame)
{
l_int32  n1, n2, i, rval1, rval2, gval1, gval2, bval1, bval2, aval1, aval2;

    PROCNAME("cmapEqual");

    if (!psame)
        return ERROR_INT("&same not defined", procName, 1);
    *psame = FALSE;
    if (!cmap1)
        return ERROR_INT("cmap1 not defined", procName, 1);
    if (!cmap2)
        return ERROR_INT("cmap2 not defined", procName, 1);
    if (ncomps != 3 && ncomps != 4)
        return ERROR_INT("ncomps not 3 or 4", procName, 1);

    n1 = pixcmapGetCount(cmap1);
    n2 = pixcmapGetCount(cmap2);
    if (n1 != n2) {
        L_INFO("colormap sizes are different\n", procName);
        return 0;
    }

    for (i = 0; i < n1; i++) {
        pixcmapGetRGBA(cmap1, i, &rval1, &gval1, &bval1, &aval1);
        pixcmapGetRGBA(cmap2, i, &rval2, &gval2, &bval2, &aval2);
        if (rval1 != rval2 || gval1 != gval2 || bval1 != bval2)
            return 0;
        if (ncomps == 4 && aval1 != aval2)
            return 0;
    }
    *psame = TRUE;
    return 0;
}