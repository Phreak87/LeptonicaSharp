﻿

l_ok
compareTilesByHisto(NUMAA      *naa1,
                    NUMAA      *naa2,
                    l_float32   minratio,
                    l_int32     w1,
                    l_int32     h1,
                    l_int32     w2,
                    l_int32     h2,
                    l_float32  *pscore,
                    PIXA       *pixadebug)
{
char       buf1[128], buf2[128];
l_int32    i, n;
l_float32  wratio, hratio, score, minscore, dist;
L_BMF     *bmf;
NUMA      *na1, *na2, *nadist, *nascore;

    PROCNAME("compareTilesByHisto");

    if (!pscore)
        return ERROR_INT("&score not defined", procName, 1);
    *pscore = 0.0;
    if (!naa1 || !naa2)
        return ERROR_INT("naa1 and naa2 not both defined", procName, 1);

        /* Filter for different sizes */
    n = numaaGetCount(naa1);
    if (n != numaaGetCount(naa2))
        return ERROR_INT("naa1 and naa2 are different size", procName, 1);

    if (pixadebug) {
        lept_rmdir("lept/comptile");
        lept_mkdir("lept/comptile");
    }

    wratio = (w1 < w2) ? (l_float32)w1 / (l_float32)w2 :
             (l_float32)w2 / (l_float32)w1;
    hratio = (h1 < h2) ? (l_float32)h1 / (l_float32)h2 :
             (l_float32)h2 / (l_float32)h1;
    if (wratio < minratio || hratio < minratio) {
        if (pixadebug)
            L_INFO("Sizes differ: wratio = %f, hratio = %f\n",
                   procName, wratio, hratio);
        return 0;
    }

        /* Evaluate histograms in each tile.  Remove white before
         * computing EMD, because there are may be a lot of white
         * pixels due to padding, and we don't want to include them.
         * This also makes the debug histo plots more informative. */
    minscore = 1.0;
    nadist = numaCreate(n);
    nascore = numaCreate(n);
    bmf = (pixadebug) ? bmfCreate(NULL, 6) : NULL;
    for (i = 0; i < n; i++) {
        na1 = numaaGetNuma(naa1, i, L_CLONE);
        na2 = numaaGetNuma(naa2, i, L_CLONE);
        numaSetValue(na1, 255, 0.0);
        numaSetValue(na2, 255, 0.0);

            /* To compare histograms, use the normalized earthmover distance.
             * Further normalize to get the EM distance as a fraction of the
             * maximum distance in the histogram (255).  Finally, scale this
             * up by 10.0, and subtract from 1.0 to get a similarity score. */
        numaEarthMoverDistance(na1, na2, &dist);
        score = L_MAX(0.0, 1.0 - 10.0 * (dist / 255.));
        numaAddNumber(nadist, dist);
        numaAddNumber(nascore, score);
        minscore = L_MIN(minscore, score);
        if (pixadebug) {
            snprintf(buf1, sizeof(buf1), "/tmp/lept/comptile/plot.%d", i);
            gplotSimple2(na1, na2, GPLOT_PNG, buf1, "Histos");
        }
        numaDestroy(&na1);
        numaDestroy(&na2);
    }
    *pscore = minscore;

    if (pixadebug) {
        for (i = 0; i < n; i++) {
            PIX  *pix1, *pix2;
            snprintf(buf1, sizeof(buf1), "/tmp/lept/comptile/plot.%d.png", i);
            pix1 = pixRead(buf1);
            numaGetFValue(nadist, i, &dist);
            numaGetFValue(nascore, i, &score);
            snprintf(buf2, sizeof(buf2),
                 "Image %d\ndist = %5.3f, score = %5.3f", i, dist, score);
            pix2 = pixAddTextlines(pix1, bmf, buf2, 0x0000ff00, L_ADD_BELOW);
            pixaAddPix(pixadebug, pix2, L_INSERT);
            pixDestroy(&pix1);
        }
        fprintf(stderr, "Writing to /tmp/lept/comptile/comparegray.pdf\n");
        pixaConvertToPdf(pixadebug, 300, 1.0, L_FLATE_ENCODE, 0, NULL,
                         "/tmp/lept/comptile/comparegray.pdf");
        numaWriteDebug("/tmp/lept/comptile/scores.na", nascore);
        numaWriteDebug("/tmp/lept/comptile/dists.na", nadist);
    }

    bmfDestroy(&bmf);
    numaDestroy(&nadist);
    numaDestroy(&nascore);
    return 0;
}