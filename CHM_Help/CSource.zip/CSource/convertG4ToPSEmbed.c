﻿

l_ok
convertG4ToPSEmbed(const char  *filein,
                   const char  *fileout)
{
char         *outstr;
l_int32       w, h, nbytes, ret;
l_float32     xpt, ypt, wpt, hpt;
L_COMP_DATA  *cid;

    PROCNAME("convertG4ToPSEmbed");

    if (!filein)
        return ERROR_INT("filein not defined", procName, 1);
    if (!fileout)
        return ERROR_INT("fileout not defined", procName, 1);

    if ((cid = l_generateG4Data(filein, 1)) == NULL)
        return ERROR_INT("g4 data not made", procName, 1);
    w = cid->w;
    h = cid->h;

        /* Scale for 20 pt boundary and otherwise full filling
         * in one direction on 8.5 x 11 inch device */
    xpt = 20.0;
    ypt = 20.0;
    if (w * 11.0 > h * 8.5) {
        wpt = 572.0;   /* 612 - 2 * 20 */
        hpt = wpt * (l_float32)h / (l_float32)w;
    } else {
        hpt = 752.0;   /* 792 - 2 * 20 */
        wpt = hpt * (l_float32)w / (l_float32)h;
    }

        /* Generate the PS, painting through the image mask.
         * The bounding box information should be inserted (default). */
    outstr = generateG4PS(NULL, cid, xpt, ypt, wpt, hpt, 1, 1, 1);
    l_CIDataDestroy(&cid);
    if (!outstr)
        return ERROR_INT("outstr not made", procName, 1);
    nbytes = strlen(outstr);

    ret = l_binaryWrite(fileout, "w", outstr, nbytes);
    LEPT_FREE(outstr);
    if (ret) L_ERROR("ps string not written to file\n", procName);
    return ret;
}