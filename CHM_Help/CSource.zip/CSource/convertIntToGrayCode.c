﻿

l_uint32
convertIntToGrayCode(l_uint32 val)
{
    return (val >> 1) ^ val;
}