﻿

l_ok
convertLABToXYZ(l_float32   lval,
                l_float32   aval,
                l_float32   bval,
                l_float32  *pxval,
                l_float32  *pyval,
                l_float32  *pzval)
{
l_float32  fx, fy, fz;
l_float32  xw = 242.37;  /* x component corresponding to rgb white */
l_float32  yw = 255.0;  /* y component corresponding to rgb white */
l_float32  zw = 277.69;  /* z component corresponding to rgb white */

    PROCNAME("convertLABToXYZ");

    if (pxval) *pxval = 0.0;
    if (pyval) *pyval = 0.0;
    if (pzval) *pzval = 0.0;
    if (!pxval || !pyval || !pzval)
        return ERROR_INT("&xval, &yval, &zval not all defined", procName, 1);

    fy = 0.0086207 * (16.0 + lval);
    fx = fy + 0.002 * aval;
    fz = fy - 0.005 * bval;
    *pxval = xw * lab_reverse(fx);
    *pyval = yw * lab_reverse(fy);
    *pzval = zw * lab_reverse(fz);
    return 0;
}