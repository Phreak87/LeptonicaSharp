﻿

l_ok
convertXYZToLAB(l_float32   xval,
                l_float32   yval,
                l_float32   zval,
                l_float32  *plval,
                l_float32  *paval,
                l_float32  *pbval)
{
l_float32  xn, yn, zn, fx, fy, fz;

    PROCNAME("convertXYZToLAB");

    if (plval) *plval = 0.0;
    if (paval) *paval = 0.0;
    if (pbval) *pbval = 0.0;
    if (!plval || !paval || !pbval)
        return ERROR_INT("&lval, &aval, &bval not all defined", procName, 1);

        /* First normalize to the corresponding white values */
    xn = 0.0041259 * xval;
    yn = 0.0039216 * yval;
    zn = 0.0036012 * zval;
        /* Then apply the lab_forward function */
    fx = lab_forward(xn);
    fy = lab_forward(yn);
    fz = lab_forward(zn);
    *plval = 116.0 * fy - 16.0;
    *paval = 500.0 * (fx - fy);
    *pbval = 200.0 * (fy - fz);
    return 0;
}