﻿

l_ok
convertXYZToRGB(l_float32  fxval,
                l_float32  fyval,
                l_float32  fzval,
                l_int32    blackout,
                l_int32   *prval,
                l_int32   *pgval,
                l_int32   *pbval)
{
l_int32  rval, gval, bval;

    PROCNAME("convertXYZToRGB");

    if (prval) *prval = 0;
    if (pgval) *pgval = 0;
    if (pbval) *pbval = 0;
    if (!prval || !pgval ||!pbval)
        return ERROR_INT("&rval, &gval, &bval not all defined", procName, 1);
    *prval = *pgval = *pbval = 0;

    rval = (l_int32)(3.2405 * fxval - 1.5372 * fyval - 0.4985 * fzval + 0.5);
    gval = (l_int32)(-0.9693 * fxval + 1.8760 * fyval + 0.0416 * fzval + 0.5);
    bval = (l_int32)(0.0556 * fxval - 0.2040 * fyval + 1.0573 * fzval + 0.5);
    if (blackout == 0) {  /* the usual situation; use nearest rgb color */
        *prval = L_MAX(0, L_MIN(rval, 255));
        *pgval = L_MAX(0, L_MIN(gval, 255));
        *pbval = L_MAX(0, L_MIN(bval, 255));
    } else {  /* use black for out of gamut */
        if (rval >= 0 && rval < 256 && gval >= 0 && gval < 256 &&
            bval >= 0 && bval < 256) {  /* in gamut */
            *prval = rval;
            *pgval = gval;
            *pbval = bval;
        }
    }
    return 0;
}