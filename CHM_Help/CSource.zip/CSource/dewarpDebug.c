﻿

l_ok
dewarpDebug(L_DEWARP    *dew,
            const char  *subdirs,
            l_int32      index)
{
char     fname[256];
char    *outdir;
l_int32  svd, shd;
PIX     *pixv, *pixh;

    PROCNAME("dewarpDebug");

    if (!dew)
        return ERROR_INT("dew not defined", procName, 1);
    if (!subdirs)
        return ERROR_INT("subdirs not defined", procName, 1);

    fprintf(stderr, "pageno = %d, hasref = %d, refpage = %d\n",
            dew->pageno, dew->hasref, dew->refpage);
    fprintf(stderr, "sampling = %d, redfactor = %d, minlines = %d\n",
            dew->sampling, dew->redfactor, dew->minlines);
    svd = shd = 0;
    if (!dew->hasref) {
        if (dew->sampvdispar) svd = 1;
        if (dew->samphdispar) shd = 1;
        fprintf(stderr, "sampv = %d, samph = %d\n", svd, shd);
        fprintf(stderr, "w = %d, h = %d\n", dew->w, dew->h);
        fprintf(stderr, "nx = %d, ny = %d\n", dew->nx, dew->ny);
        fprintf(stderr, "nlines = %d\n", dew->nlines);
        if (svd) {
            fprintf(stderr, "(min,max,abs-diff) line curvature = (%d,%d,%d)\n",
                    dew->mincurv, dew->maxcurv, dew->maxcurv - dew->mincurv);
        }
        if (shd) {
            fprintf(stderr, "(left edge slope = %d, right edge slope = %d\n",
                    dew->leftslope, dew->rightslope);
            fprintf(stderr, "(left,right,abs-diff) edge curvature = "
                    "(%d,%d,%d)\n", dew->leftcurv, dew->rightcurv,
                    L_ABS(dew->leftcurv - dew->rightcurv));
        }
    }
    if (!svd && !shd) {
        fprintf(stderr, "No disparity arrays\n");
        return 0;
    }

    dewarpPopulateFullRes(dew, NULL, 0, 0);
    lept_mkdir(subdirs);
    outdir = pathJoin("/tmp", subdirs);
    if (svd) {
        pixv = fpixRenderContours(dew->fullvdispar, 3.0, 0.15);
        snprintf(fname, sizeof(fname), "%s/pixv_%d.png", outdir, index);
        pixWriteDebug(fname, pixv, IFF_PNG);
        pixDestroy(&pixv);
    }
    if (shd) {
        pixh = fpixRenderContours(dew->fullhdispar, 3.0, 0.15);
        snprintf(fname, sizeof(fname), "%s/pixh_%d.png", outdir, index);
        pixWriteDebug(fname, pixh, IFF_PNG);
        pixDestroy(&pixh);
    }
    LEPT_FREE(outdir);
    return 0;
}