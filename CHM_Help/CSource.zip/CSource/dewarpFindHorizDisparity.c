﻿

l_ok
dewarpFindHorizDisparity(L_DEWARP  *dew,
                         PTAA      *ptaa)
{
l_int32    i, j, h, nx, ny, sampling, ret;
l_float32  c0, c1, cl0, cl1, cl2, cr0, cr1, cr2;
l_float32  x, y, refl, refr;
l_float32  val, mederr;
NUMA      *nald, *nard;
PIX       *pix1;
PTA       *ptal1, *ptar1;  /* left/right end points of lines; initial */
PTA       *ptal2, *ptar2;  /* left/right end points; after filtering */
PTA       *ptal3, *ptar3;  /* left and right block, fitted, uniform spacing */
PTA       *pta, *ptat, *pta1, *pta2;
PTAA      *ptaah;
FPIX      *fpix;

    PROCNAME("dewarpFindHorizDisparity");

    if (!dew)
        return ERROR_INT("dew not defined", procName, 1);
    dew->hsuccess = 0;
    if (!ptaa)
        return ERROR_INT("ptaa not defined", procName, 1);

    if (dew->debug) L_INFO("finding horizontal disparity\n", procName);

        /* Get the endpoints of the lines, and sort from top to bottom */
    h = pixGetHeight(dew->pixs);
    ret = dewarpGetLineEndPoints(h, ptaa, &ptal1, &ptar1);
    if (ret) {
        L_INFO("Horiz disparity not built\n", procName);
        return 1;
    }
    if (dew->debug) {
        lept_mkdir("lept/dewdebug");
        lept_mkdir("lept/dewarp");
        ptaWriteDebug("/tmp/lept/dewdebug/endpts_left1.pta", ptal1, 1);
        ptaWriteDebug("/tmp/lept/dewdebug/endpts_right1.pta", ptar1, 1);
    }

        /* Filter the points by x-location to prevent 2-column images
         * from getting confused about left and right endpoints. We
         * require valid left points to not be farther than
         *     0.20 * (remaining distance to the right edge of the image)
         * to the right of the leftmost endpoint, and similarly for
         * the right endpoints. (Note: x and y are reversed in the pta.)
         * Also require end points to be near the medians in the
         * upper and lower halves. */
    ret = dewarpFilterLineEndPoints(dew, ptal1, ptar1, &ptal2, &ptar2);
    ptaDestroy(&ptal1);
    ptaDestroy(&ptar1);

        /* Do a quadratic fit to the left and right endpoints of the
         * longest lines.  Each line is represented by 3 coefficients:
         *     x(y) = c2 * y^2 + c1 * y + c0.
         * Using the coefficients, sample each fitted curve uniformly
         * along the full height of the image. */
    sampling = dew->sampling;
    nx = dew->nx;
    ny = dew->ny;

        /* Fit the left side, using quadratic LSF on the set of long
         * lines.  It is not necessary to use the noisy LSF fit
         * function, because we've removed outlier end points by
         * selecting the long lines.  Then uniformly sample along
         * this fitted curve. */
    dewarpQuadraticLSF(ptal2, &cl2, &cl1, &cl0, &mederr);
    dew->leftslope = lept_roundftoi(1000. * cl1);  /* milli-units */
    dew->leftcurv = lept_roundftoi(1000000. * cl2);  /* micro-units */
    L_INFO("Left quad LSF median error = %5.2f\n", procName,  mederr);
    L_INFO("Left edge slope = %d\n", procName, dew->leftslope);
    L_INFO("Left edge curvature = %d\n", procName, dew->leftcurv);
    ptal3 = ptaCreate(ny);
    for (i = 0; i < ny; i++) {  /* uniformly sampled in y */
        y = i * sampling;
        applyQuadraticFit(cl2, cl1, cl0, y, &x);
        ptaAddPt(ptal3, x, y);
    }

        /* Fit the right side in the same way. */
    dewarpQuadraticLSF(ptar2, &cr2, &cr1, &cr0, &mederr);
    dew->rightslope = lept_roundftoi(1000.0 * cr1);  /* milli-units */
    dew->rightcurv = lept_roundftoi(1000000. * cr2);  /* micro-units */
    L_INFO("Right quad LSF median error = %5.2f\n", procName,  mederr);
    L_INFO("Right edge slope = %d\n", procName, dew->rightslope);
    L_INFO("Right edge curvature = %d\n", procName, dew->rightcurv);
    ptar3 = ptaCreate(ny);
    for (i = 0; i < ny; i++) {  /* uniformly sampled in y */
        y = i * sampling;
        applyQuadraticFit(cr2, cr1, cr0, y, &x);
        ptaAddPt(ptar3, x, y);
    }

    if (dew->debug) {
        PTA  *ptalft, *ptarft;
        h = pixGetHeight(dew->pixs);
        pta1 = ptaCreate(h);
        pta2 = ptaCreate(h);
        for (i = 0; i < h; i++) {
            applyQuadraticFit(cl2, cl1, cl0, i, &x);
            ptaAddPt(pta1, x, i);
            applyQuadraticFit(cr2, cr1, cr0, i, &x);
            ptaAddPt(pta2, x, i);
        }
        pix1 = pixDisplayPta(NULL, dew->pixs, pta1);
        pixDisplayPta(pix1, pix1, pta2);
        pixRenderHorizEndPoints(pix1, ptal2, ptar2, 0xff000000);
        pixDisplay(pix1, 600, 800);
        pixWriteDebug("/tmp/lept/dewmod/0051.png", pix1, IFF_PNG);
        pixDestroy(&pix1);

        pix1 = pixDisplayPta(NULL, dew->pixs, pta1);
        pixDisplayPta(pix1, pix1, pta2);
        ptalft = ptaTranspose(ptal3);
        ptarft = ptaTranspose(ptar3);
        pixRenderHorizEndPoints(pix1, ptalft, ptarft, 0x0000ff00);
        pixDisplay(pix1, 800, 800);
        pixWriteDebug("/tmp/lept/dewmod/0052.png", pix1, IFF_PNG);
        convertFilesToPdf("/tmp/lept/dewmod", "005", 135, 1.0, 0, 0,
                          "Dewarp Horiz Disparity",
                          "/tmp/lept/dewarp/horiz_disparity.pdf");
        fprintf(stderr, "pdf file: /tmp/lept/dewarp/horiz_disparity.pdf\n");
        pixDestroy(&pix1);
        ptaDestroy(&pta1);
        ptaDestroy(&pta2);
        ptaDestroy(&ptalft);
        ptaDestroy(&ptarft);
    }

        /* Find the x value at the midpoints (in y) of the two vertical lines,
         * ptal3 and ptar3.  These are the reference values for each of the
         * lines.  Then use the difference between the these midpoint
         * values and the actual x coordinates of the lines to represent
         * the horizontal disparity (nald, nard) on the vertical lines
         * for the sampled y values. */
    ptaGetPt(ptal3, ny / 2, &refl, NULL);
    ptaGetPt(ptar3, ny / 2, &refr, NULL);
    nald = numaCreate(ny);
    nard = numaCreate(ny);
    for (i = 0; i < ny; i++) {
        ptaGetPt(ptal3, i, &x, NULL);
        numaAddNumber(nald, refl - x);
        ptaGetPt(ptar3, i, &x, NULL);
        numaAddNumber(nard, refr - x);
    }

        /* Now for each pair of sampled values of the two lines (at the
         * same value of y), do a linear interpolation to generate
         * the horizontal disparity on all sampled points between them.  */
    ptaah = ptaaCreate(ny);
    for (i = 0; i < ny; i++) {
        pta = ptaCreate(2);
        numaGetFValue(nald, i, &val);
        ptaAddPt(pta, refl, val);
        numaGetFValue(nard, i, &val);
        ptaAddPt(pta, refr, val);
        ptaGetLinearLSF(pta, &c1, &c0, NULL);  /* horiz disparity along line */
        ptat = ptaCreate(nx);
        for (j = 0; j < nx; j++) {
            x = j * sampling;
            applyLinearFit(c1, c0, x, &val);
            ptaAddPt(ptat, x, val);
        }
        ptaaAddPta(ptaah, ptat, L_INSERT);
        ptaDestroy(&pta);
    }
    numaDestroy(&nald);
    numaDestroy(&nard);

        /* Save the result in a fpix at the specified subsampling  */
    fpix = fpixCreate(nx, ny);
    for (i = 0; i < ny; i++) {
        for (j = 0; j < nx; j++) {
            ptaaGetPt(ptaah, i, j, NULL, &val);
            fpixSetPixel(fpix, j, i, val);
        }
    }
    dew->samphdispar = fpix;
    dew->hsuccess = 1;
    ptaDestroy(&ptal2);
    ptaDestroy(&ptar2);
    ptaDestroy(&ptal3);
    ptaDestroy(&ptar3);
    ptaaDestroy(&ptaah);
    return 0;
}