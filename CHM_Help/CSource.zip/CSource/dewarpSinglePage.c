﻿

l_ok
dewarpSinglePage(PIX         *pixs,
                 l_int32      thresh,
                 l_int32      adaptive,
                 l_int32      useboth,
                 l_int32      check_columns,
                 PIX        **ppixd,
                 L_DEWARPA  **pdewa,
                 l_int32      debug)
{
L_DEWARPA  *dewa;
PIX        *pixb;

    PROCNAME("dewarpSinglePage");

    if (!ppixd)
        return ERROR_INT("&pixd not defined", procName, 1);
    *ppixd = NULL;
    if (pdewa) *pdewa = NULL;
    if (!pixs)
        return ERROR_INT("pixs not defined", procName, 1);

    dewarpSinglePageInit(pixs, thresh, adaptive, useboth,
                         check_columns, &pixb, &dewa);
    if (!pixb) {
        dewarpaDestroy(&dewa);
        return ERROR_INT("pixb not made", procName, 1);
    }

    dewarpSinglePageRun(pixs, pixb, dewa, ppixd, debug);

    if (pdewa)
        *pdewa = dewa;
    else
        dewarpaDestroy(&dewa);
    pixDestroy(&pixb);
    return 0;
}