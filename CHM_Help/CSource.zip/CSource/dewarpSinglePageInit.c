﻿

l_ok
dewarpSinglePageInit(PIX         *pixs,
                     l_int32      thresh,
                     l_int32      adaptive,
                     l_int32      useboth,
                     l_int32      check_columns,
                     PIX        **ppixb,
                     L_DEWARPA  **pdewa)
{
PIX  *pix1;

    PROCNAME("dewarpSinglePageInit");

    if (ppixb) *ppixb = NULL;
    if (pdewa) *pdewa = NULL;
    if (!ppixb || !pdewa)
        return ERROR_INT("&pixb and &dewa not both defined", procName, 1);
    if (!pixs)
        return ERROR_INT("pixs not defined", procName, 1);

    *pdewa = dewarpaCreate(1, 0, 1, 0, -1);
    dewarpaUseBothArrays(*pdewa, useboth);
    dewarpaSetCheckColumns(*pdewa, check_columns);

         /* Generate a binary image, if necessary */
    if (pixGetDepth(pixs) > 1) {
        pix1 = pixConvertTo8(pixs, 0);
        if (adaptive)
            *ppixb = pixAdaptThresholdToBinary(pix1, NULL, 1.0);
        else
            *ppixb = pixThresholdToBinary(pix1, thresh);
        pixDestroy(&pix1);
    } else {
        *ppixb = pixClone(pixs);
    }
    return 0;
}