﻿
static const l_int32  INITIAL_PTR_ARRAYSIZE = 20
static const l_int32     MAX_PTR_ARRAYSIZE = 10000
static const l_int32     DEFAULT_ARRAY_SAMPLING = 30
static const l_int32     MIN_ARRAY_SAMPLING = 8
static const l_int32     DEFAULT_MIN_LINES = 15
static const l_int32     MIN_MIN_LINES = 4
static const l_int32     DEFAULT_MAX_REF_DIST = 16
static const l_int32     DEFAULT_MAX_LINECURV = 180
static const l_int32     DEFAULT_MIN_DIFF_LINECURV = 0
static const l_int32     DEFAULT_MAX_DIFF_LINECURV = 200
static const l_int32     DEFAULT_MAX_EDGESLOPE = 80
static const l_int32     DEFAULT_MAX_EDGECURV = 50
static const l_int32     DEFAULT_MAX_DIFF_EDGECURV = 40
static const l_int32     DEFAULT_CHECK_COLUMNS = FALSE
static const l_int32     DEFAULT_USE_BOTH = TRUE

L_DEWARPA *
dewarpaCreate(l_int32  nptrs,
              l_int32  sampling,
              l_int32  redfactor,
              l_int32  minlines,
              l_int32  maxdist)
{
L_DEWARPA  *dewa;

    PROCNAME("dewarpaCreate");

    if (nptrs <= 0)
        nptrs = INITIAL_PTR_ARRAYSIZE;
    if (nptrs > MAX_PTR_ARRAYSIZE)
        return (L_DEWARPA *)ERROR_PTR("too many pages", procName, NULL);
    if (redfactor != 1 && redfactor != 2)
        return (L_DEWARPA *)ERROR_PTR("redfactor not in {1,2}",
                                      procName, NULL);
    if (sampling == 0) {
         sampling = DEFAULT_ARRAY_SAMPLING;
    } else if (sampling < MIN_ARRAY_SAMPLING) {
         L_WARNING("sampling too small; setting to %d\n", procName,
                   MIN_ARRAY_SAMPLING);
         sampling = MIN_ARRAY_SAMPLING;
    }
    if (minlines == 0) {
        minlines = DEFAULT_MIN_LINES;
    } else if (minlines < MIN_MIN_LINES) {
        L_WARNING("minlines too small; setting to %d\n", procName,
                  MIN_MIN_LINES);
        minlines = DEFAULT_MIN_LINES;
    }
    if (maxdist < 0)
         maxdist = DEFAULT_MAX_REF_DIST;

    dewa = (L_DEWARPA *)LEPT_CALLOC(1, sizeof(L_DEWARPA));
    dewa->dewarp = (L_DEWARP **)LEPT_CALLOC(nptrs, sizeof(L_DEWARPA *));
    dewa->dewarpcache = (L_DEWARP **)LEPT_CALLOC(nptrs, sizeof(L_DEWARPA *));
    if (!dewa->dewarp || !dewa->dewarpcache) {
        dewarpaDestroy(&dewa);
        return (L_DEWARPA *)ERROR_PTR("dewarp ptrs not made", procName, NULL);
    }
    dewa->nalloc = nptrs;
    dewa->sampling = sampling;
    dewa->redfactor = redfactor;
    dewa->minlines = minlines;
    dewa->maxdist = maxdist;
    dewa->max_linecurv = DEFAULT_MAX_LINECURV;
    dewa->min_diff_linecurv = DEFAULT_MIN_DIFF_LINECURV;
    dewa->max_diff_linecurv = DEFAULT_MAX_DIFF_LINECURV;
    dewa->max_edgeslope = DEFAULT_MAX_EDGESLOPE;
    dewa->max_edgecurv = DEFAULT_MAX_EDGECURV;
    dewa->max_diff_edgecurv = DEFAULT_MAX_DIFF_EDGECURV;
    dewa->check_columns = DEFAULT_CHECK_COLUMNS;
    dewa->useboth = DEFAULT_USE_BOTH;
    return dewa;
}