﻿
static const l_int32     DEFAULT_MAX_LINECURV = 180
static const l_int32     DEFAULT_MIN_DIFF_LINECURV = 0
static const l_int32     DEFAULT_MAX_DIFF_LINECURV = 200
static const l_int32     DEFAULT_MAX_EDGECURV = 50
static const l_int32     DEFAULT_MAX_DIFF_EDGECURV = 40
static const l_int32     DEFAULT_MAX_EDGESLOPE = 80

l_ok
dewarpaSetCurvatures(L_DEWARPA  *dewa,
                     l_int32     max_linecurv,
                     l_int32     min_diff_linecurv,
                     l_int32     max_diff_linecurv,
                     l_int32     max_edgecurv,
                     l_int32     max_diff_edgecurv,
                     l_int32     max_edgeslope)
{
    PROCNAME("dewarpaSetCurvatures");

    if (!dewa)
        return ERROR_INT("dewa not defined", procName, 1);

    if (max_linecurv == -1)
        dewa->max_linecurv = DEFAULT_MAX_LINECURV;
    else
        dewa->max_linecurv = L_ABS(max_linecurv);

    if (min_diff_linecurv == -1)
        dewa->min_diff_linecurv = DEFAULT_MIN_DIFF_LINECURV;
    else
        dewa->min_diff_linecurv = L_ABS(min_diff_linecurv);

    if (max_diff_linecurv == -1)
        dewa->max_diff_linecurv = DEFAULT_MAX_DIFF_LINECURV;
    else
        dewa->max_diff_linecurv = L_ABS(max_diff_linecurv);

    if (max_edgecurv == -1)
        dewa->max_edgecurv = DEFAULT_MAX_EDGECURV;
    else
        dewa->max_edgecurv = L_ABS(max_edgecurv);

    if (max_diff_edgecurv == -1)
        dewa->max_diff_edgecurv = DEFAULT_MAX_DIFF_EDGECURV;
    else
        dewa->max_diff_edgecurv = L_ABS(max_diff_edgecurv);

    if (max_edgeslope == -1)
        dewa->max_edgeslope = DEFAULT_MAX_EDGESLOPE;
    else
        dewa->max_edgeslope = L_ABS(max_edgeslope);

    dewa->modelsready = 0;  /* force validation */
    return 0;
}