﻿

DPIX *
dpixReadMem(const l_uint8  *data,
            size_t          size)
{
FILE  *fp;
DPIX  *dpix;

    PROCNAME("dpixReadMem");

    if (!data)
        return (DPIX *)ERROR_PTR("data not defined", procName, NULL);
    if ((fp = fopenReadFromMemory(data, size)) == NULL)
        return (DPIX *)ERROR_PTR("stream not opened", procName, NULL);

    dpix = dpixReadStream(fp);
    fclose(fp);
    if (!dpix) L_ERROR("dpix not read\n", procName);
    return dpix;
}