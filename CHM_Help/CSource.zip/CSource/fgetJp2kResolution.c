﻿

l_int32
fgetJp2kResolution(FILE     *fp,
                   l_int32  *pxres,
                   l_int32  *pyres)
{
l_uint8    xexp, yexp;
l_uint8   *data;
l_uint16   xnum, ynum, xdenom, ydenom;  /* these jp2k fields are 2-byte */
l_int32    loc, found;
l_uint8    resc[4] = {0x72, 0x65, 0x73, 0x63};  /* 'resc' */
size_t     nbytes;
l_float64  xres, yres;

    PROCNAME("fgetJp2kResolution");

    if (pxres) *pxres = 0;
    if (pyres) *pyres = 0;
    if (!pxres || !pyres)
        return ERROR_INT("&xres and &yres not both defined", procName, 1);
    if (!fp)
        return ERROR_INT("stream not opened", procName, 1);

    rewind(fp);
    data = l_binaryReadStream(fp, &nbytes);
    rewind(fp);

        /* Search for the start of the first capture resolution box: 'resc' */
    arrayFindSequence(data, nbytes, resc, 4, &loc, &found);
    if (!found) {
        L_WARNING("image resolution not found\n", procName);
        LEPT_FREE(data);
        return 1;
    }

        /* Extract the fields and calculate the resolution in pixels/meter.
         * See section 1.5.3.7.1 of JPEG 2000 ISO/IEC 15444-1 spec.  */
    ynum = data[loc + 5] << 8 | data[loc + 4];
    ynum = convertOnLittleEnd16(ynum);
    ydenom = data[loc + 7] << 8 | data[loc + 6];
    ydenom = convertOnLittleEnd16(ydenom);
    xnum = data[loc + 9] << 8 | data[loc + 8];
    xnum = convertOnLittleEnd16(xnum);
    xdenom = data[loc + 11] << 8 | data[loc + 10];
    xdenom = convertOnLittleEnd16(xdenom);
    yexp = data[loc + 12];
    xexp = data[loc + 13];
    yres = ((l_float64)ynum / (l_float64)ydenom) * pow(10.0, (l_float64)yexp);
    xres = ((l_float64)xnum / (l_float64)xdenom) * pow(10.0, (l_float64)xexp);

        /* Convert from pixels/meter to ppi */
    yres *= (300.0 / 11811.0);
    xres *= (300.0 / 11811.0);
    *pyres = (l_int32)(yres + 0.5);
    *pxres = (l_int32)(xres + 0.5);

    LEPT_FREE(data);
    return 0;
}