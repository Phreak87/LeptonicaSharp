﻿

l_ok
fhmtautogen(SELA        *sela,
            l_int32      fileindex,
            const char  *filename)
{
l_int32  ret1, ret2;

    PROCNAME("fhmtautogen");

    if (!sela)
        return ERROR_INT("sela not defined", procName, 1);
    ret1 = fhmtautogen1(sela, fileindex, filename);
    ret2 = fhmtautogen2(sela, fileindex, filename);
    if (ret1 || ret2)
        return ERROR_INT("code generation problem", procName, 1);
    return 0;
}