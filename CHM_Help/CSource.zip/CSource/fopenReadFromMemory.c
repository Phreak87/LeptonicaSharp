﻿

FILE *
fopenReadFromMemory(const l_uint8  *data,
                    size_t          size)
{
FILE  *fp;

    PROCNAME("fopenReadFromMemory");

    if (!data)
        return (FILE *)ERROR_PTR("data not defined", procName, NULL);

#if HAVE_FMEMOPEN
    if ((fp = fmemopen((void *)data, size, "rb")) == NULL)
        return (FILE *)ERROR_PTR("stream not opened", procName, NULL);
#else  /* write to tmp file */
    L_INFO("work-around: writing to a temp file\n", procName);
  #ifdef _WIN32
    if ((fp = fopenWriteWinTempfile()) == NULL)
        return (FILE *)ERROR_PTR("tmpfile stream not opened", procName, NULL);
  #else
    if ((fp = tmpfile()) == NULL)
        return (FILE *)ERROR_PTR("tmpfile stream not opened", procName, NULL);
  #endif  /*  _WIN32 */
    fwrite(data, 1, size, fp);
    rewind(fp);
#endif  /* HAVE_FMEMOPEN */

    return fp;
}