﻿

FILE *
fopenWriteWinTempfile()
{
#ifdef _WIN32
l_int32  handle;
FILE    *fp;
char    *filename;

    PROCNAME("fopenWriteWinTempfile");

    if ((filename = l_makeTempFilename()) == NULL) {
        L_ERROR("l_makeTempFilename failed, %s\n", procName, strerror(errno));
        return NULL;
    }

    handle = _open(filename, _O_CREAT | _O_RDWR | _O_SHORT_LIVED |
                   _O_TEMPORARY | _O_BINARY, _S_IREAD | _S_IWRITE);
    lept_free(filename);
    if (handle == -1) {
        L_ERROR("_open failed, %s\n", procName, strerror(errno));
        return NULL;
    }

    if ((fp = _fdopen(handle, "r+b")) == NULL) {
        L_ERROR("_fdopen failed, %s\n", procName, strerror(errno));
        return NULL;
    }

    return fp;
#else
    return NULL;
#endif  /*  _WIN32 */
}