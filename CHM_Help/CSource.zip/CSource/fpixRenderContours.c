﻿

PIX *
fpixRenderContours(FPIX      *fpixs,
                   l_float32  incr,
                   l_float32  proxim)
{
l_int32     i, j, w, h, wpls, wpld;
l_float32   val, invincr, finter, above, below, diff;
l_uint32   *datad, *lined;
l_float32  *datas, *lines;
PIX        *pixd;
PIXCMAP    *cmap;

    PROCNAME("fpixRenderContours");

    if (!fpixs)
        return (PIX *)ERROR_PTR("fpixs not defined", procName, NULL);
    if (incr <= 0.0)
        return (PIX *)ERROR_PTR("incr <= 0.0", procName, NULL);
    if (proxim <= 0.0)
        proxim = 0.15;  /* default */

    fpixGetDimensions(fpixs, &w, &h);
    if ((pixd = pixCreate(w, h, 8)) == NULL)
        return (PIX *)ERROR_PTR("pixd not made", procName, NULL);
    cmap = pixcmapCreate(8);
    pixSetColormap(pixd, cmap);
    pixcmapAddColor(cmap, 255, 255, 255);  /* white */
    pixcmapAddColor(cmap, 0, 0, 0);  /* black */
    pixcmapAddColor(cmap, 255, 0, 0);  /* red */

    datas = fpixGetData(fpixs);
    wpls = fpixGetWpl(fpixs);
    datad = pixGetData(pixd);
    wpld = pixGetWpl(pixd);
    invincr = 1.0 / incr;
    for (i = 0; i < h; i++) {
        lines = datas + i * wpls;
        lined = datad + i * wpld;
        for (j = 0; j < w; j++) {
            val = lines[j];
            finter = invincr * val;
            above = finter - floorf(finter);
            below = ceilf(finter) - finter;
            diff = L_MIN(above, below);
            if (diff <= proxim) {
                if (val < 0.0)
                    SET_DATA_BYTE(lined, j, 2);
                else
                    SET_DATA_BYTE(lined, j, 1);
            }
        }
    }

    return pixd;
}