﻿

l_ok
fpixWrite(const char  *filename,
          FPIX        *fpix)
{
l_int32  ret;
FILE    *fp;

    PROCNAME("fpixWrite");

    if (!filename)
        return ERROR_INT("filename not defined", procName, 1);
    if (!fpix)
        return ERROR_INT("fpix not defined", procName, 1);

    if ((fp = fopenWriteStream(filename, "wb")) == NULL)
        return ERROR_INT("stream not opened", procName, 1);
    ret = fpixWriteStream(fp, fpix);
    fclose(fp);
    if (ret)
        return ERROR_INT("fpix not written to stream", procName, 1);
    return 0;
}