﻿

l_ok
fpixaAddFPix(FPIXA   *fpixa,
             FPIX    *fpix,
             l_int32  copyflag)
{
l_int32  n;
FPIX    *fpixc;

    PROCNAME("fpixaAddFPix");

    if (!fpixa)
        return ERROR_INT("fpixa not defined", procName, 1);
    if (!fpix)
        return ERROR_INT("fpix not defined", procName, 1);

    if (copyflag == L_INSERT)
        fpixc = fpix;
    else if (copyflag == L_COPY)
        fpixc = fpixCopy(NULL, fpix);
    else if (copyflag == L_CLONE)
        fpixc = fpixClone(fpix);
    else
        return ERROR_INT("invalid copyflag", procName, 1);
    if (!fpixc)
        return ERROR_INT("fpixc not made", procName, 1);

    n = fpixaGetCount(fpixa);
    if (n >= fpixa->nalloc)
        fpixaExtendArray(fpixa);
    fpixa->fpix[n] = fpixc;
    fpixa->n++;

    return 0;
}