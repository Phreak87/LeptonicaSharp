﻿

PIX *
fpixaConvertXYZToRGB(FPIXA  *fpixa)
{
l_int32     w, h, wpls, wpld, i, j, rval, gval, bval;
l_float32   fxval, fyval, fzval;
l_float32  *linex, *liney, *linez, *datax, *datay, *dataz;
l_uint32   *lined, *datad;
PIX        *pixd;
FPIX       *fpix;

    PROCNAME("fpixaConvertXYZToRGB");

    if (!fpixa || fpixaGetCount(fpixa) != 3)
        return (PIX *)ERROR_PTR("fpixa undefined or invalid", procName, NULL);

        /* Convert XYZ image */
    if (fpixaGetFPixDimensions(fpixa, 0, &w, &h))
        return (PIX *)ERROR_PTR("fpixa dimensions not found", procName, NULL);
    pixd = pixCreate(w, h, 32);
    wpld = pixGetWpl(pixd);
    datad = pixGetData(pixd);
    datax = fpixaGetData(fpixa, 0);
    datay = fpixaGetData(fpixa, 1);
    dataz = fpixaGetData(fpixa, 2);
    fpix = fpixaGetFPix(fpixa, 0, L_CLONE);
    wpls = fpixGetWpl(fpix);
    fpixDestroy(&fpix);
    for (i = 0; i < h; i++) {
        linex = datax + i * wpls;
        liney = datay + i * wpls;
        linez = dataz + i * wpls;
        lined = datad + i * wpld;
        for (j = 0; j < w; j++) {
            fxval = linex[j];
            fyval = liney[j];
            fzval = linez[j];
            convertXYZToRGB(fxval, fyval, fzval, 0, &rval, &gval, &bval);
            composeRGBPixel(rval, gval, bval, lined + j);
        }
    }

    return pixd;
}