﻿

void
fpixaDestroy(FPIXA  **pfpixa)
{
l_int32  i;
FPIXA   *fpixa;

    PROCNAME("fpixaDestroy");

    if (pfpixa == NULL) {
        L_WARNING("ptr address is NULL!\n", procName);
        return;
    }

    if ((fpixa = *pfpixa) == NULL)
        return;

        /* Decrement the refcount.  If it is 0, destroy the pixa. */
    fpixaChangeRefcount(fpixa, -1);
    if (fpixa->refcount <= 0) {
        for (i = 0; i < fpixa->n; i++)
            fpixDestroy(&fpixa->fpix[i]);
        LEPT_FREE(fpixa->fpix);
        LEPT_FREE(fpixa);
    }

    *pfpixa = NULL;
    return;
}