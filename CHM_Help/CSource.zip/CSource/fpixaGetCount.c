﻿

l_int32
fpixaGetCount(FPIXA  *fpixa)
{
    PROCNAME("fpixaGetCount");

    if (!fpixa)
        return ERROR_INT("fpixa not defined", procName, 0);

    return fpixa->n;
}