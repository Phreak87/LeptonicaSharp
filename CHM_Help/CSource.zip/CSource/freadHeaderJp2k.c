﻿

l_ok
freadHeaderJp2k(FILE     *fp,
                l_int32  *pw,
                l_int32  *ph,
                l_int32  *pbps,
                l_int32  *pspp)
{
l_uint8  buf[80];  /* just need the first 80 bytes */
l_int32  nread;

    PROCNAME("freadHeaderJp2k");

    if (pw) *pw = 0;
    if (ph) *ph = 0;
    if (pbps) *pbps = 0;
    if (pspp) *pspp = 0;
    if (!fp)
        return ERROR_INT("fp not defined", procName, 1);

    rewind(fp);
    nread = fread(buf, 1, sizeof(buf), fp);
    if (nread != sizeof(buf))
        return ERROR_INT("read failure", procName, 1);

    readHeaderMemJp2k(buf, sizeof(buf), pw, ph, pbps, pspp);
    rewind(fp);
    return 0;
}