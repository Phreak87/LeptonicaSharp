﻿tatic const l_int32  MAX_PNM_WIDTH = 100000;
tatic const l_int32  MAX_PNM_HEIGHT = 100000;

_ok
freadHeaderPnm(FILE     *fp,
               l_int32  *pw,
               l_int32  *ph,
               l_int32  *pd,
               l_int32  *ptype,
               l_int32  *pbps,
               l_int32  *pspp)
{
char     tag[16], tupltype[32];
l_int32  i, w, h, d, bps, spp, type;
l_int32  maxval;
l_int32  ch;

    PROCNAME("freadHeaderPnm");

    if (pw) *pw = 0;
    if (ph) *ph = 0;
    if (pd) *pd = 0;
    if (ptype) *ptype = 0;
    if (pbps) *pbps = 0;
    if (pspp) *pspp = 0;
    if (!fp)
        return ERROR_INT("fp not defined", procName, 1);

    if (fscanf(fp, "P%d\n", &type) != 1)
        return ERROR_INT("invalid read for type", procName, 1);
    if (type < 1 || type > 7)
        return ERROR_INT("invalid pnm file", procName, 1);

    if (pnmSkipCommentLines(fp))
        return ERROR_INT("no data in file", procName, 1);

    if (type == 7) {
        w = h = d = bps = spp = maxval = 0;
        for (i = 0; i < 10; i++) {   /* limit to 10 lines of this header */
            if (pnmReadNextString(fp, tag, sizeof(tag)))
                return ERROR_INT("found no next tag", procName, 1);
            if (!strcmp(tag, "WIDTH")) {
                if (pnmReadNextNumber(fp, &w))
                    return ERROR_INT("failed reading width", procName, 1);
                continue;
            }
            if (!strcmp(tag, "HEIGHT")) {
                if (pnmReadNextNumber(fp, &h))
                    return ERROR_INT("failed reading height", procName, 1);
                continue;
            }
            if (!strcmp(tag, "DEPTH")) {
                if (pnmReadNextNumber(fp, &spp))
                    return ERROR_INT("failed reading depth", procName, 1);
                continue;
            }
            if (!strcmp(tag, "MAXVAL")) {
                if (pnmReadNextNumber(fp, &maxval))
                    return ERROR_INT("failed reading maxval", procName, 1);
                continue;
            }
            if (!strcmp(tag, "TUPLTYPE")) {
                if (pnmReadNextString(fp, tupltype, sizeof(tupltype)))
                    return ERROR_INT("failed reading tuple type", procName, 1);
                continue;
            }
            if (!strcmp(tag, "ENDHDR")) {
                if ('\n' != (ch = fgetc(fp)))
                    return ERROR_INT("missing LF after ENDHDR", procName, 1);
                break;
            }
        }
        if (w <= 0 || h <= 0 || w > MAX_PNM_WIDTH || h > MAX_PNM_HEIGHT) {
            L_INFO("invalid size: w = %d, h = %d\n", procName, w, h);
            return 1;
        }
        if (maxval == 1) {
            d = bps = 1;
        } else if (maxval == 3) {
            d = bps = 2;
        } else if (maxval == 15) {
            d = bps = 4;
        } else if (maxval == 255) {
            d = bps = 8;
        } else if (maxval == 0xffff) {
            d = bps = 16;
        } else {
            L_INFO("invalid maxval = %d\n", procName, maxval);
            return 1;
        }
        switch (spp) {
        case 1:
            /* d and bps are already set */
            break;
        case 2:
        case 3:
        case 4:
            /* create a 32 bpp Pix */
            d = 32;
            break;
        default:
            L_INFO("invalid depth = %d\n", procName, spp);
            return 1;
        }
    } else {

        if (fscanf(fp, "%d %d\n", &w, &h) != 2)
            return ERROR_INT("invalid read for w,h", procName, 1);
        if (w <= 0 || h <= 0 || w > MAX_PNM_WIDTH || h > MAX_PNM_HEIGHT) {
            L_INFO("invalid size: w = %d, h = %d\n", procName, w, h);
            return 1;
        }

       /* Get depth of pix.  For types 2 and 5, we use the maxval.
        * Important implementation note:
        *   - You can't use fscanf(), which throws away whitespace,
        *     and will discard binary data if it starts with whitespace(s).
        *   - You can't use fgets(), which stops at newlines, but this
        *     dumb format doesn't require a newline after the maxval
        *     number -- it just requires one whitespace character.
        *   - Which leaves repeated calls to fgetc, including swallowing
        *     the single whitespace character. */
        if (type == 1 || type == 4) {
            d = 1;
            spp = 1;
            bps = 1;
        } else if (type == 2 || type == 5) {
            if (pnmReadNextNumber(fp, &maxval))
                return ERROR_INT("invalid read for maxval (2,5)", procName, 1);
            if (maxval == 3) {
                d = 2;
            } else if (maxval == 15) {
                d = 4;
            } else if (maxval == 255) {
                d = 8;
            } else if (maxval == 0xffff) {
                d = 16;
            } else {
                fprintf(stderr, "maxval = %d\n", maxval);
                return ERROR_INT("invalid maxval", procName, 1);
            }
            bps = d;
            spp = 1;
        } else {  /* type == 3 || type == 6; this is rgb  */
            if (pnmReadNextNumber(fp, &maxval))
                return ERROR_INT("invalid read for maxval (3,6)", procName, 1);
            if (maxval != 255)
                L_WARNING("unexpected maxval = %d\n", procName, maxval);
            d = 32;
            spp = 3;
            bps = 8;
        }
    }
    if (pw) *pw = w;
    if (ph) *ph = h;
    if (pd) *pd = d;
    if (ptype) *ptype = type;
    if (pbps) *pbps = bps;
    if (pspp) *pspp = spp;
    return 0;
}

