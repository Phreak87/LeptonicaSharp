﻿
static l_int32  var_PS_WRITE_BOUNDING_BOX = 1

char *
generateFlatePS(const char   *filein,
                L_COMP_DATA  *cid,
                l_float32     xpt,
                l_float32     ypt,
                l_float32     wpt,
                l_float32     hpt,
                l_int32       pageno,
                l_int32       endpage)
{
l_int32  w, h, bps, spp;
char    *outstr;
char     bigbuf[L_BUF_SIZE];
SARRAY  *sa;

    PROCNAME("generateFlatePS");

    if (!cid)
        return (char *)ERROR_PTR("flate data not defined", procName, NULL);
    w = cid->w;
    h = cid->h;
    bps = cid->bps;
    spp = cid->spp;

    if ((sa = sarrayCreate(50)) == NULL)
        return (char *)ERROR_PTR("sa not made", procName, NULL);

    sarrayAddString(sa, "%!PS-Adobe-3.0 EPSF-3.0", L_COPY);
    sarrayAddString(sa, "%%Creator: leptonica", L_COPY);
    if (filein)
        snprintf(bigbuf, sizeof(bigbuf), "%%%%Title: %s", filein);
    else
        snprintf(bigbuf, sizeof(bigbuf), "%%%%Title: Flate compressed PS");
    sarrayAddString(sa, bigbuf, L_COPY);
    sarrayAddString(sa, "%%DocumentData: Clean7Bit", L_COPY);

    if (var_PS_WRITE_BOUNDING_BOX == 1) {
        snprintf(bigbuf, sizeof(bigbuf),
                 "%%%%BoundingBox: %7.2f %7.2f %7.2f %7.2f",
                 xpt, ypt, xpt + wpt, ypt + hpt);
        sarrayAddString(sa, bigbuf, L_COPY);
    }

    sarrayAddString(sa, "%%LanguageLevel: 3", L_COPY);
    sarrayAddString(sa, "%%EndComments", L_COPY);
    snprintf(bigbuf, sizeof(bigbuf), "%%%%Page: %d %d", pageno, pageno);
    sarrayAddString(sa, bigbuf, L_COPY);

    sarrayAddString(sa, "save", L_COPY);
    snprintf(bigbuf, sizeof(bigbuf),
           "%7.2f %7.2f translate         %%set image origin in pts", xpt, ypt);
    sarrayAddString(sa, bigbuf, L_COPY);

    snprintf(bigbuf, sizeof(bigbuf),
             "%7.2f %7.2f scale             %%set image size in pts", wpt, hpt);
    sarrayAddString(sa, bigbuf, L_COPY);

        /* If there is a colormap, add the data; it is now owned by sa */
    if (cid->cmapdata85) {
        snprintf(bigbuf, sizeof(bigbuf),
                 "[ /Indexed /DeviceRGB %d          %%set colormap type/size",
                 cid->ncolors - 1);
        sarrayAddString(sa, bigbuf, L_COPY);
        sarrayAddString(sa, "  <~", L_COPY);
        sarrayAddString(sa, cid->cmapdata85, L_INSERT);
        sarrayAddString(sa, "  ] setcolorspace", L_COPY);
    } else if (spp == 1) {
        sarrayAddString(sa, "/DeviceGray setcolorspace", L_COPY);
    } else {  /* spp == 3 */
        sarrayAddString(sa, "/DeviceRGB setcolorspace", L_COPY);
    }

    sarrayAddString(sa,
                    "/RawData currentfile /ASCII85Decode filter def", L_COPY);
    sarrayAddString(sa,
                    "/Data RawData << >> /FlateDecode filter def", L_COPY);

    sarrayAddString(sa, "{ << /ImageType 1", L_COPY);
    snprintf(bigbuf, sizeof(bigbuf), "     /Width %d", w);
    sarrayAddString(sa, bigbuf, L_COPY);
    snprintf(bigbuf, sizeof(bigbuf), "     /Height %d", h);
    sarrayAddString(sa, bigbuf, L_COPY);
    snprintf(bigbuf, sizeof(bigbuf), "     /BitsPerComponent %d", bps);
    sarrayAddString(sa, bigbuf, L_COPY);
    snprintf(bigbuf, sizeof(bigbuf),
            "     /ImageMatrix [ %d 0 0 %d 0 %d ]", w, -h, h);
    sarrayAddString(sa, bigbuf, L_COPY);

    if (cid->cmapdata85) {
        sarrayAddString(sa, "     /Decode [0 255]", L_COPY);
    } else if (spp == 1) {
        if (bps == 1)  /* miniswhite photometry */
            sarrayAddString(sa, "     /Decode [1 0]", L_COPY);
        else  /* bps > 1 */
            sarrayAddString(sa, "     /Decode [0 1]", L_COPY);
    } else {  /* spp == 3 */
        sarrayAddString(sa, "     /Decode [0 1 0 1 0 1]", L_COPY);
    }

    sarrayAddString(sa, "     /DataSource Data", L_COPY);
    sarrayAddString(sa, "  >> image", L_COPY);
    sarrayAddString(sa, "  Data closefile", L_COPY);
    sarrayAddString(sa, "  RawData flushfile", L_COPY);
    if (endpage == TRUE)
        sarrayAddString(sa, "  showpage", L_COPY);
    sarrayAddString(sa, "  restore", L_COPY);
    sarrayAddString(sa, "} exec", L_COPY);

        /* Insert the ascii85 gzipped data; this is now owned by sa */
    sarrayAddString(sa, cid->data85, L_INSERT);

        /* Generate and return the output string */
    outstr = sarrayToString(sa, 1);
    sarrayDestroy(&sa);
    cid->cmapdata85 = NULL;  /* it has been transferred to sa and destroyed */
    cid->data85 = NULL;  /* it has been transferred to sa and destroyed */
    return outstr;
}